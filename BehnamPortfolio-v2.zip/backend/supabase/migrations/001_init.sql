-- =====================================================================
-- 001_init.sql | ساختار دیتابیس (PostgreSQL / Supabase)
-- ⚠️ این فایل اجرا و تست نشده است (محیط ساخت، PostgreSQL نداشت).
--    قبل از استفاده در یک پروژه Supabase آزمایشی اجرا و بررسی شود.
--
-- اصول:
--  * مالکیت و دسترسی در سطح دیتابیس (RLS) اعمال می‌شود، نه فقط در رابط کاربری.
--  * کاربر عادی هرگز وضعیت پروژه را تغییر نمی‌دهد (فقط سرویس مدیریت).
--  * کد OTP خام ذخیره نمی‌شود؛ فقط هش آن (جدول otp_challenges فقط برای service_role).
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- نوع‌های شمارشی ----------
create type project_status as enum ('submitted','in_review','need_info','approved','in_progress','completed','rejected');
create type consult_status as enum ('submitted','answered','closed');

-- ---------- کاربران (پروفایل) ----------
-- id همان شناسه کاربر در auth.users است (Supabase). برای Node/Postgres خالص، به جدول users خودت وصل کن.
create table public.profiles (
    id                  uuid primary key references auth.users(id) on delete cascade,
    username            text not null,
    display_name        text not null,
    email               text,
    phone               text,
    avatar_path         text,
    account_status      text not null default 'active' check (account_status in ('active','suspended')),
    username_changed_at timestamptz,
    created_at          timestamptz not null default now(),
    updated_at          timestamptz not null default now(),
    constraint username_format check (username ~ '^[A-Za-z0-9._-]{3,20}$' and username !~ '^[._-]|[._-]$'),
    constraint phone_e164 check (phone is null or phone ~ '^\+[1-9][0-9]{7,14}$')
);
create unique index profiles_username_lower_uq on public.profiles (lower(username));
create unique index profiles_email_lower_uq on public.profiles (lower(email)) where email is not null;
create unique index profiles_phone_uq on public.profiles (phone) where phone is not null;

-- ---------- شماره پیگیری یکتا (فقط در سرور ساخته می‌شود) ----------
create or replace function public.generate_tracking_code() returns text
language plpgsql as $$
declare
    alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    code text;
begin
    loop
        code := 'BH-';
        for i in 1..6 loop
            code := code || substr(alphabet, 1 + (get_byte(gen_random_bytes(1), 0) % length(alphabet)), 1);
        end loop;
        exit when not exists (select 1 from public.projects where tracking_code = code);
    end loop;
    return code;
end $$;

-- ---------- پروژه‌ها ----------
create table public.projects (
    id             uuid primary key default gen_random_uuid(),
    owner_id       uuid not null references public.profiles(id) on delete cascade,
    tracking_code  text not null unique default public.generate_tracking_code(),
    title          text not null check (char_length(title) between 3 and 120),
    category       text not null check (category in ('website','wordpress','dev','ai','brand','content','video','other')),
    description    text not null check (char_length(description) between 20 and 3000),
    goal           text not null check (char_length(goal) between 10 and 1500),
    requirements   text not null check (char_length(requirements) between 10 and 3000),
    audience       text check (char_length(audience) <= 200),
    refs           text check (char_length(refs) <= 1500),
    assets         text[] not null default '{}',
    budget         text check (char_length(budget) <= 60),
    start_when     text not null check (start_when in ('asap','month','flex')),
    deadline       text not null check (deadline in ('2w','4w','3m','long','unknown')),
    priority       text not null default 'normal' check (priority in ('low','normal','high')),
    status         project_status not null default 'submitted',
    created_at     timestamptz not null default now(),
    updated_at     timestamptz not null default now()
);
create index projects_owner_idx on public.projects (owner_id, created_at desc);

create table public.project_files (
    id          uuid primary key default gen_random_uuid(),
    project_id  uuid not null references public.projects(id) on delete cascade,
    owner_id    uuid not null references public.profiles(id) on delete cascade,
    path        text not null,            -- مسیر در Storage: {owner_id}/{project_id}/{uuid}.{ext}
    original_name text not null,
    mime_type   text not null check (mime_type in ('image/jpeg','image/png','image/webp','application/pdf')),
    size_bytes  integer not null check (size_bytes between 1 and 5242880),
    created_at  timestamptz not null default now()
);

-- ---------- درخواست‌های مشاوره ----------
create table public.consultation_requests (
    id             uuid primary key default gen_random_uuid(),
    owner_id       uuid references public.profiles(id) on delete set null,   -- مهمان: null
    name           text not null check (char_length(name) between 2 and 80),
    contact_method text not null check (contact_method in ('phone','email','telegram')),
    contact_value  text not null check (char_length(contact_value) <= 120),
    subject        text not null check (subject in ('website','wordpress','dev','ai','brand','content','video','other')),
    description    text not null check (char_length(description) between 10 and 1500),
    preferred_time text not null default 'any' check (preferred_time in ('morning','afternoon','evening','any')),
    status         consult_status not null default 'submitted',
    created_at     timestamptz not null default now()
);

-- ---------- اعلان‌ها ----------
create table public.notifications (
    id         uuid primary key default gen_random_uuid(),
    user_id    uuid not null references public.profiles(id) on delete cascade,
    title      text not null,
    message    text not null,
    read_at    timestamptz,
    created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

-- اعلان خودکار هنگام تغییر وضعیت پروژه
create or replace function public.notify_status_change() returns trigger language plpgsql security definer as $$
begin
    if new.status is distinct from old.status then
        insert into public.notifications (user_id, title, message)
        values (new.owner_id, 'status:' || new.status::text, new.tracking_code);
    end if;
    new.updated_at := now();
    return new;
end $$;
create trigger projects_status_notify before update on public.projects
    for each row execute function public.notify_status_change();

-- ---------- چالش‌های OTP (فقط service_role) ----------
create table public.otp_challenges (
    id            uuid primary key default gen_random_uuid(),
    purpose       text not null check (purpose in ('login','register','change_contact')),
    channel       text not null check (channel in ('phone','email')),
    target        text not null,
    code_hash     text not null,           -- HMAC-SHA256(code, OTP_PEPPER)؛ هرگز کد خام
    expires_at    timestamptz not null,
    attempts      smallint not null default 0,
    consumed_at   timestamptz,
    sends_in_window smallint not null default 1,
    ip            inet,
    created_at    timestamptz not null default now()
);
create index otp_target_idx on public.otp_challenges (channel, target, created_at desc);

-- =====================================================================
-- RLS: دسترسی در سطح دیتابیس
-- =====================================================================
alter table public.profiles              enable row level security;
alter table public.projects              enable row level security;
alter table public.project_files         enable row level security;
alter table public.consultation_requests enable row level security;
alter table public.notifications         enable row level security;
alter table public.otp_challenges        enable row level security;   -- بدون policy = فقط service_role

-- پروفایل: فقط مالک می‌خواند و فقط فیلدهای مجاز را تغییر می‌دهد
create policy profiles_select_own on public.profiles for select using (id = auth.uid());
create policy profiles_update_own on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
revoke update on public.profiles from authenticated;
grant  update (display_name, avatar_path) on public.profiles to authenticated;
-- تغییر username/email/phone فقط از طریق Edge Function (محدودیت زمانی + تأیید مالکیت)

-- پروژه: مالک می‌بیند و فقط برای خودش ثبت می‌کند؛ تغییر وضعیت/ویرایش با کاربر نیست
create policy projects_select_own on public.projects for select using (owner_id = auth.uid());
create policy projects_insert_own on public.projects for insert with check (owner_id = auth.uid() and status = 'submitted');
revoke update, delete on public.projects from authenticated;

create policy files_select_own on public.project_files for select using (owner_id = auth.uid());
create policy files_insert_own on public.project_files for insert with check (
    owner_id = auth.uid() and exists (select 1 from public.projects p where p.id = project_id and p.owner_id = auth.uid()));

-- مشاوره: خواندن فقط برای مالک. ثبت (به‌خصوص مهمان) فقط از Edge Function با محدودیت نرخ و کپچا
create policy consult_select_own on public.consultation_requests for select using (owner_id = auth.uid());

-- اعلان: خواندن و فقط علامت‌گذاری «خوانده‌شده»
create policy notif_select_own on public.notifications for select using (user_id = auth.uid());
create policy notif_update_own on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke update on public.notifications from authenticated;
grant  update (read_at) on public.notifications to authenticated;

-- =====================================================================
-- Storage: سطل خصوصی فایل‌های پروژه (حجم و نوع در سطح سطل هم محدود است)
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('project-files', 'project-files', false, 5242880, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do nothing;

create policy "project files: owner read" on storage.objects for select
    using (bucket_id = 'project-files' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "project files: owner upload" on storage.objects for insert
    with check (bucket_id = 'project-files' and (storage.foldername(name))[1] = auth.uid()::text);

# -*- coding: utf-8 -*-
# متن صفحات حریم خصوصی و قوانین.
# توجه: این متن‌ها یک پیش‌نویس هستند و قبل از انتشار رسمی باید با شرایط واقعی سرویس‌های انتخاب‌شده
# (ارائه‌دهنده پیامک، ایمیل، دیتابیس و ...) و در صورت نیاز با مشاور حقوقی بازبینی شوند.

S = {
    "legal.updated": ("آخرین بروزرسانی", "Last updated"),
    "legal.draftNote": ("این صفحه به‌صورت خودکار با تنظیمات فعلی سایت نوشته شده است.", "This page reflects the site's current setup."),
    "privacy.title": ("حریم خصوصی", "Privacy Policy"),
    "privacy.intro": ("در این صفحه توضیح می‌دهیم چه اطلاعاتی جمع‌آوری می‌شود، چرا جمع‌آوری می‌شود و چه کنترلی روی آن داری. فقط اطلاعاتی را می‌خواهیم که برای کار کردن حساب و بررسی درخواست‌هایت لازم است.",
                      "This page explains what information is collected, why it is collected and the control you have over it. We only ask for what is needed to run your account and review your requests."),
    "privacy.body": (
        "<h2>اطلاعاتی که جمع‌آوری می‌شود</h2>"
        "<ul><li><strong>اطلاعات حساب:</strong> نام کاربری، نام نمایشی، شماره موبایل یا ایمیل و در صورت انتخاب تو، تصویر پروفایل.</li>"
        "<li><strong>ورود با Google یا Apple:</strong> شناسه حساب و ایمیلی که آن سرویس در اختیار می‌گذارد؛ رمز عبور شما را دریافت نمی‌کنیم.</li>"
        "<li><strong>اطلاعات پروژه و مشاوره:</strong> عنوان، توضیحات، بودجه و زمان‌بندی، فایل‌های پیوست و راه ارتباطی‌ای که خودت وارد می‌کنی.</li>"
        "<li><strong>اطلاعات فنی:</strong> برای امنیت و جلوگیری از سوءاستفاده (مثلاً محدودیت تعداد درخواست‌ها) ممکن است آدرس IP و زمان درخواست‌ها ثبت شود.</li>"
        "<li><strong>ذخیره‌سازی در مرورگر:</strong> انتخاب تم و زبان در مرورگرت نگه‌داری می‌شود و ورود به حساب از طریق نشست امن انجام می‌شود.</li></ul>"
        "<h2>دلیل جمع‌آوری</h2>"
        "<ul><li>ساخت حساب و تأیید هویت (کد تأیید).</li><li>بررسی درخواست‌های پروژه و مشاوره و پاسخ به آن‌ها.</li>"
        "<li>اطلاع‌رسانی درباره تغییر وضعیت پروژه‌هایت.</li><li>امنیت حساب و جلوگیری از سوءاستفاده.</li></ul>"
        "<h2>مدت نگهداری</h2>"
        "<p>اطلاعات حساب و درخواست‌هایت تا زمانی که حساب فعال است نگهداری می‌شود. پس از درخواست حذف حساب، اطلاعات مرتبط حذف می‌شود؛ مگر مواردی که قانون یا امنیت سامانه نگهداری محدود آن‌ها را ایجاب کند.</p>"
        "<h2>اشتراک‌گذاری اطلاعات</h2>"
        "<p>اطلاعات تو فروخته نمی‌شود. فقط در حد لازم با سرویس‌هایی که برای اجرای سایت به کار می‌روند (مانند ارسال پیامک و ایمیل، ورود با Google یا Apple و میزبانی داده) به اشتراک گذاشته می‌شود.</p>"
        "<h2>حقوق تو</h2>"
        "<p>می‌توانی اطلاعات حسابت را در پنل کاربری ببینی و ویرایش کنی و هر زمان که خواستی حساب خود را از بخش «امنیت حساب» حذف کنی.</p>"
        "<h2>ارتباط</h2>"
        "<p>برای هر سؤال درباره حریم خصوصی از راه‌های ارتباطی انتهای صفحه با من در تماس باش.</p>",

        "<h2>Information we collect</h2>"
        "<ul><li><strong>Account details:</strong> username, display name, mobile number or email and, if you choose, a profile photo.</li>"
        "<li><strong>Sign-in with Google or Apple:</strong> the account identifier and email that service shares with us; we never receive your password.</li>"
        "<li><strong>Project and consultation details:</strong> the title, description, budget, timeline, attached files and contact method you enter.</li>"
        "<li><strong>Technical data:</strong> for security and abuse prevention (for example rate limiting) your IP address and request times may be recorded.</li>"
        "<li><strong>Browser storage:</strong> your theme and language choices are stored in your browser, and sign-in is kept through a secure session.</li></ul>"
        "<h2>Why we collect it</h2>"
        "<ul><li>To create your account and verify your identity (verification code).</li><li>To review and answer project and consultation requests.</li>"
        "<li>To notify you when a project's status changes.</li><li>To keep accounts secure and prevent abuse.</li></ul>"
        "<h2>How long we keep it</h2>"
        "<p>Your account details and requests are kept while your account is active. After you ask to delete your account the related data is removed, except where the law or system security requires limited retention.</p>"
        "<h2>Sharing</h2>"
        "<p>Your information is not sold. It is shared only as needed with the services that run the site, such as SMS and email delivery, sign-in with Google or Apple, and data hosting.</p>"
        "<h2>Your rights</h2>"
        "<p>You can view and edit your account details in the dashboard and delete your account at any time from the “Security” page.</p>"
        "<h2>Contact</h2>"
        "<p>For any privacy question, reach out using the contact options at the bottom of the page.</p>"),

    "terms.title": ("قوانین استفاده", "Terms of Service"),
    "terms.intro": ("با استفاده از این وب‌سایت و ساخت حساب کاربری، قوانین زیر را می‌پذیری.", "By using this website and creating an account, you agree to the following terms."),
    "terms.body": (
        "<h2>حساب کاربری</h2>"
        "<p>اطلاعاتی که هنگام ثبت‌نام وارد می‌کنی باید درست باشد و مسئولیت امنیت دسترسی به شماره موبایل، ایمیل و حساب‌هایت با خودت است.</p>"
        "<h2>ثبت پروژه و مشاوره</h2>"
        "<p>ارسال درخواست پروژه یا مشاوره به معنی شروع قرارداد نیست. دامنه کار، زمان و شرایط همکاری پس از بررسی و توافق دو طرف مشخص می‌شود.</p>"
        "<h2>محتوایی که ارسال می‌کنی</h2>"
        "<p>فایل‌ها و توضیحاتی که می‌فرستی باید متعلق به خودت باشد یا اجازه استفاده از آن را داشته باشی و نباید غیرقانونی، مخرب یا ناقض حقوق دیگران باشد.</p>"
        "<h2>استفاده نادرست</h2>"
        "<p>ارسال انبوه درخواست، تلاش برای دور زدن محدودیت‌ها یا دسترسی به اطلاعات دیگران مجاز نیست و ممکن است به محدود شدن حساب منجر شود.</p>"
        "<h2>در دسترس بودن سایت</h2>"
        "<p>تلاش می‌کنیم سایت پایدار باشد، اما امکان قطعی یا تغییر در خدمات وجود دارد.</p>"
        "<h2>تغییر قوانین</h2>"
        "<p>این قوانین ممکن است بروزرسانی شود؛ نسخه فعلی همیشه در همین صفحه قرار دارد.</p>",

        "<h2>Your account</h2>"
        "<p>The details you provide when registering must be accurate, and you are responsible for keeping your phone number, email and accounts secure.</p>"
        "<h2>Project and consultation requests</h2>"
        "<p>Submitting a project or consultation request does not start a contract. The scope, timeline and terms are set after review and agreement between both sides.</p>"
        "<h2>Content you send</h2>"
        "<p>Files and descriptions you send must belong to you or you must have permission to use them, and must not be unlawful, harmful or infringe on others' rights.</p>"
        "<h2>Misuse</h2>"
        "<p>Mass-submitting requests, trying to bypass limits or accessing other people's data is not allowed and may lead to your account being restricted.</p>"
        "<h2>Availability</h2>"
        "<p>We aim to keep the site reliable, but interruptions or changes to the service may happen.</p>"
        "<h2>Changes to these terms</h2>"
        "<p>These terms may be updated; the current version is always on this page.</p>"),
}

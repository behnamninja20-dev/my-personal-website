# -*- coding: utf-8 -*-
"""
تبدیل یک‌باره index.html فعلی به قالب src/pages/home.html

- بخش Hero عیناً از فایل فعلی برداشته می‌شود (فقط متن‌ها به کلید ترجمه تبدیل می‌شوند).
- بخش‌های مهارت‌ها و ابزارها با همان ساختار قبلی ساخته می‌شوند، با کلیدهای ترجمه.
- بخش‌های جدید (شروع پروژه، مشاوره، ارتباط) از partial های جداگانه می‌آیند.
"""
import json, re, pathlib

HERE = pathlib.Path(__file__).parent
orig = (HERE.parent / "backup-before-v2" / "index.html").read_text(encoding="utf-8").replace("\r\n", "\n")
logos = json.loads((HERE / "logos.json").read_text(encoding="utf-8"))

# ---------------- Hero ----------------
a = orig.index('<section class="hero page-container" id="about">')
b = orig.index('<section class="cloud-section page-container" id="skills">')
hero = orig[a:b]


def sub_once(text, old, new):
    assert old in text, f"پیدا نشد: {old[:40]}"
    return text.replace(old, new, 1)


hero = sub_once(hero, "در حال ساختن چیزهای مفید", "{{hero.status}}")
hero = sub_once(hero, "از ایده تا اجرا،", "{{hero.title1}}")
hero = sub_once(hero, "با کد تمیز.", "{{hero.title2}}")
hero = re.sub(r'(<p class="hero-description">).*?(</p>)', r"\1{{hero.desc}}\2", hero, count=1, flags=re.S)
hero = sub_once(hero, '<a href="#contact" class="btn btn-primary">ثبت پروژه</a>',
                '<a href="{{@url:project-new}}" class="btn btn-primary">{{hero.cta}}</a>')
hero = sub_once(hero, "دیدن نمونه‌کارها", "{{hero.work}}")
hero = sub_once(hero, "طراحی، توسعه و خلق تجربه‌های دیجیتال", "{{hero.meta}}")
hero = sub_once(hero, 'aria-label="نمایش نمونه کد برنامه‌نویسی"', 'aria-label="{{hero.visualAria}}"')
hero = sub_once(hero, "۲+ سال تجربه", "{{hero.tagTop}}")
hero = sub_once(hero, "خلاقیت، حل مسئله", "{{hero.tagBottom}}")
hero = sub_once(hero, "<div class=\"divider page-container\"></div>", "<div class=\"divider page-container\"></div>")

# ---------------- Skills ----------------
SKILLS = [
    ("web", "web", 3), ("wordpress", "wp", 3), ("ai", "ai", 4),
    ("brand", "brand", 3), ("content", "content", 3), ("video", "video", 3),
]
ICONS = {
    "web": '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18"/><path d="M10 13l-2 2 2 2"/><path d="M14 13l2 2-2 2"/>',
    "wordpress": '<rect x="3" y="3" width="8" height="9" rx="2"/><rect x="13" y="3" width="8" height="5" rx="2"/><rect x="13" y="10" width="8" height="11" rx="2"/><rect x="3" y="14" width="8" height="7" rx="2"/>',
    "ai": '<rect x="3" y="14" width="6" height="6" rx="1.5"/><rect x="15" y="14" width="6" height="6" rx="1.5"/><path d="M6 14v-2a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v2"/><path d="M12 9V6"/><path d="M12 2.5l.9 2 2 .9-2 .9-.9 2-.9-2-2-.9 2-.9z"/>',
    "brand": '<path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.6 7.6"/><circle cx="11" cy="11" r="2"/>',
    "content": '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="1.7"/><path d="M21 15l-5-5L5 21"/>',
    "video": '<rect x="3" y="8" width="18" height="13" rx="2.5"/><path d="M3 12.5h18"/><path d="M5 8l3-5"/><path d="M11 8l3-5"/><path d="M17 8l3-5"/>',
}


def card(icon, k, n):
    lis = "\n".join(f"                                <li>{{{{skill.{k}.p{i}}}}}</li>" for i in range(1, n + 1))
    return f'''                    <article class="skill-card" data-reveal="card">
                        <div class="skill-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" focusable="false">{ICONS[icon]}</svg>
                        </div>
                        <div class="skill-info">
                            <h3>{{{{skill.{k}.title}}}}</h3>
                            <p>{{{{skill.{k}.desc}}}}</p>
                        </div>
                        <ul class="skill-points">
{lis}
                        </ul>
                    </article>
'''


skills_cards = "\n".join(card(*s) for s in SKILLS)

# ---------------- Tools ----------------
def inline_logo(key, defs="", fill=None):
    d = logos[key]
    f = f' fill="{fill}"' if fill else ""
    return f'<svg viewBox="{d["vb"]}" focusable="false">{defs}<path{f} d="{d["paths"][0]}"/></svg>'


GEMINI_DEFS = ('<defs><linearGradient id="gemini-gradient" x1="3" y1="21" x2="21" y2="3" gradientUnits="userSpaceOnUse">'
               '<stop offset="0" stop-color="#4796E3"/><stop offset="0.5" stop-color="#9177C7"/><stop offset="1" stop-color="#CA6673"/>'
               '</linearGradient></defs>')
DEV = "https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons"


def mask_logo(folder):
    url = f"{DEV}/{folder}/{folder}-plain.svg"
    return f'<span class="logo-mask" data-logo="{url}" style="--logo: url(\'{url}\')"></span>'


TOOLS = [
    ("dev", "DEVELOPMENT &amp; PROGRAMMING", "tools.dev", [
        ("HTML", "#E34F26", inline_logo("html")), ("CSS", "#1572B6", inline_logo("css")),
        ("JavaScript", "#F7DF1E", inline_logo("js")), ("Python", "#3776AB", inline_logo("python")),
        ("GitHub", "var(--text)", inline_logo("github"))]),
    ("ai", "AI &amp; AUTOMATION", "tools.ai", [
        ("ChatGPT", "#10A37F", inline_logo("chatgpt")), ("Claude", "#D97757", inline_logo("claude")),
        ("Gemini", "#8E75B2", inline_logo("gemini", GEMINI_DEFS, "url(#gemini-gradient)")),
        ("DeepSeek", "#4D6BFF", inline_logo("deepseek")), ("n8n", "#EA4B71", inline_logo("n8n"))]),
    ("creative", "CREATIVE &amp; VIDEO PRODUCTION", "tools.creative", [
        ("Adobe Photoshop", "#31A8FF", mask_logo("photoshop")), ("Adobe Premiere Pro", "#9999FF", mask_logo("premierepro")),
        ("Adobe After Effects", "#9999FF", mask_logo("aftereffects")), ("DaVinci Resolve", "var(--text)", inline_logo("davinci"))]),
]


def panel(key, label, title_key, items):
    tiles = "\n".join(
        f'''                            <li class="tool" style="--i: {i}; --brand: {c}">
                                <span class="tool-logo" aria-hidden="true">{l}</span>
                                <span class="tool-name">{n}</span>
                            </li>''' for i, (n, c, l) in enumerate(items))
    return f'''                    <article class="tools-panel" data-reveal aria-labelledby="tools-{key}-title">
                        <header class="tools-panel-head">
                            <span class="tools-panel-label">{label}</span>
                            <h3 id="tools-{key}-title">{{{{{title_key}}}}}</h3>
                        </header>
                        <ul class="tools-grid">
{tiles}
                        </ul>
                    </article>
'''


tools_panels = "\n".join(panel(*t) for t in TOOLS)

home = f'''{hero}
        <section class="cloud-section page-container" id="skills">
            <section class="skills-section">
                <div class="skills-container">
                    <div class="skills-details" data-reveal>
                        <span class="span-skills">MY SKILLS</span>
                        <h2>{{{{skills.title}}}}</h2>
                        <p>{{{{skills.desc}}}}</p>
                    </div>
                    <div class="skills-grid">

{skills_cards}
                    </div>
                    <div class="skills-footer" data-reveal>
                        <span class="footer-dot" aria-hidden="true"></span>
                        <p>{{{{skills.footer}}}}</p>
                    </div>
                </div>
            </section>
        </section>

        <div class="divider page-container" data-reveal></div>

        <section class="tools-wrap page-container" id="tools">
            <div class="tools-section">
                <div class="tools-container">
                    <div class="tools-details" data-reveal>
                        <span class="span-tools">TOOLS</span>
                        <h2>{{{{tools.title}}}}</h2>
                        <p>{{{{tools.desc}}}}</p>
                    </div>
                    <div class="tools-list">

{tools_panels}
                    </div>
                </div>
            </div>
        </section>

        <div class="divider page-container" data-reveal></div>

        <section class="placeholder-section page-container" id="projects">
            <h2>{{{{projects.title}}}}</h2>
            <p>{{{{projects.desc}}}}</p>
        </section>

        {{{{>start}}}}

        {{{{>consult}}}}

        {{{{>contact}}}}
'''
(HERE / "pages" / "home.html").write_text(home, encoding="utf-8")
print("home.html", len(home))

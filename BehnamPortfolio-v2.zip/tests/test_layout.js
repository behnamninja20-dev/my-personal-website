const { chromium } = require("/opt/npm-tools/node_modules/playwright");
const widths = [320,360,375,390,414,430,600,768,820,1024,1280,1440,1920];
const pages = ["", "auth/", "auth/#register", "privacy/", "dashboard/"];
(async () => {
  const b = await chromium.launch(); let bad = 0, n = 0;
  for (const lang of ["fa","en"]) for (const theme of ["light","dark"]) for (const w of widths) { if (theme==="dark" && ![320,390,768,1280].includes(w)) continue;
    const ctx = await b.newContext({ viewport:{width:w,height:w<700?800:900}, hasTouch:w<900, isMobile:w<700, colorScheme:theme });
    await ctx.route(/fonts\.|jsdelivr|flagcdn/, r=>r.abort());
    for (const p of pages) {
      const page = await ctx.newPage(); const errs=[];
      page.on("pageerror", e=>errs.push(e.message));
      page.on("console", m=>{ if(m.type()==="error" && !/Failed to load resource|ERR_FAILED/.test(m.text())) errs.push(m.text()); });
      await page.goto(`http://localhost:8765/${lang}/${p}`); await page.waitForTimeout(700);
      if (p.startsWith("dashboard")) { await page.waitForTimeout(500); }
      // پیمایش تا انتها تا همه بخش‌ها نمایش داده شوند
      const H = await page.evaluate(()=>document.documentElement.scrollHeight);
      for (let y=0;y<H;y+=500){ await page.evaluate(v=>scrollTo(0,v),y); await page.waitForTimeout(60); }
      await page.waitForTimeout(900);
      const r = await page.evaluate(()=>{
        const over = document.documentElement.scrollWidth - innerWidth;
        // عناصری که از لبه‌های صفحه بیرون زده‌اند
        const out=[...document.querySelectorAll("body *")].filter(e=>{
          const s=getComputedStyle(e); if(s.position==="fixed"||s.visibility==="hidden"||s.display==="none"||e.closest("svg,dialog,[hidden],.auth-overlay,.visual-orbit,.hero-visual,.dash-side,.lang-menu,.country-pop,.notif-pop,template,.sr-only,.skip-link,.otp-digit,.toast-region")) return false;
          const b=e.getBoundingClientRect(); if(!b.width) return false;
          return b.right>innerWidth+1||b.left<-1;
        }).slice(0,4).map(e=>e.tagName+"."+(e.className||"").toString().slice(0,30));
        const nav=document.querySelector(".navbar-inner, .auth-top, .dash-top");
        let navOK=true; if(nav){ const nb=nav.getBoundingClientRect(); navOK=[...nav.querySelectorAll(".logo,.nav-actions,.dash-top-actions,.dash-burger")].every(e=>{const b=e.getBoundingClientRect();return b.left>=nb.left-1&&b.right<=nb.right+1}); }
        return {over,out,navOK};
      });
      n++;
      if (r.over>0 || r.out.length || !r.navOK || errs.length){ bad++; console.log("BAD",lang,theme,w,p||"home",JSON.stringify(r),errs.slice(0,2)); }
      await page.close();
    }
    await ctx.close();
  }
  await b.close(); console.log(`checked ${n} page-states, problems: ${bad}`);
})();

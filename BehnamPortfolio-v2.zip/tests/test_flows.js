const { chromium } = require("/opt/npm-tools/node_modules/playwright");
const BASE = "http://localhost:8765";
let pass = 0, fail = 0;
function ok(c, name, extra) { if (c) { pass++; console.log("  ✓", name); } else { fail++; console.log("  ✗ FAIL:", name, extra || ""); } }

async function newPage(b, w = 1280, h = 900, extra = {}) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, ...extra });
  await ctx.route(/fonts\.|jsdelivr|flagcdn/, r => r.abort());
  const page = await ctx.newPage(); page.errs = [];
  page.on("pageerror", e => page.errs.push(e.message));
  return { ctx, page };
}
const q = (p, s) => p.locator(s);

async function otpType(page, pane, code) {
  const d = page.locator(`[data-pane="${pane}"] .otp-digit`);
  await d.first().click();
  await page.keyboard.type(code, { delay: 40 });
}

(async () => {
  const b = await chromium.launch();

  // ---------- ۱) مهمان و کنترل دسترسی ----------
  console.log("\n[1] Guest access control");
  let { ctx, page } = await newPage(b);
  await page.goto(`${BASE}/fa/dashboard/projects/new/`);
  await page.waitForURL(/\/fa\/auth\//, { timeout: 5000 }).catch(() => { });
  ok(/\/fa\/auth\//.test(page.url()), "guest → redirected to auth", page.url());
  ok(/next=/.test(page.url()), "redirect keeps ?next=");
  const hidden = await page.evaluate(() => document.querySelector("[data-dash-inner]") === null);
  ok(hidden, "dashboard content is not rendered on auth page");
  await page.goto(`${BASE}/fa/dashboard/`);
  await page.waitForURL(/\/fa\/auth\//, { timeout: 5000 }).catch(() => { });
  ok(/\/fa\/auth\//.test(page.url()), "direct dashboard URL also gated");
  // API-level: بدون ورود ثبت پروژه رد می‌شود
  const apiErr = await page.evaluate(() => window.AppAPI.projectCreate({ title: "x" }, []).then(() => "created", e => e.code));
  ok(apiErr === "UNAUTHENTICATED", "API rejects project creation for guests", apiErr);
  await ctx.close();

  // ---------- ۲) ثبت‌نام با موبایل + OTP ----------
  console.log("\n[2] Register with phone + OTP");
  ({ ctx, page } = await newPage(b));
  await page.goto(`${BASE}/fa/auth/?next=${encodeURIComponent("/fa/dashboard/projects/new/")}#register`);
  await page.waitForTimeout(900);
  ok(await page.locator('[data-pane="register"]').evaluate(e => !e.inert), "register pane active via #register");
  ok(await page.locator('[data-pane="login"]').evaluate(e => e.inert), "login pane is inert");
  const reg = page.locator('[data-pane="register"]');
  // اعتبارسنجی
  await reg.locator('button[type="submit"]').click();
  ok((await reg.locator('[data-err="username"]').textContent()).length > 0, "empty username shows error");
  await reg.locator('[name="username"]').fill("a!");
  await reg.locator('[name="phone"]').fill("123");
  await reg.locator('button[type="submit"]').click();
  ok((await reg.locator('[data-err="username"]').textContent()).includes("۳") || (await reg.locator('[data-err="username"]').textContent()).length > 5, "invalid username rejected");
  ok((await reg.locator('[data-err="phone"]').textContent()).length > 0, "invalid phone rejected");
  await reg.locator('[name="username"]').fill("behnam_test");
  await reg.locator('[name="displayName"]').fill("بهنام");
  await reg.locator('[name="phone"]').fill("۰۹۱۳۱۲۳۴۵۶۷");     // ارقام فارسی و صفر ابتدایی
  await reg.locator('button[type="submit"]').click();
  await reg.locator('[data-step="otp"]').waitFor({ state: "visible", timeout: 4000 });
  ok(true, "OTP step shown");
  ok((await reg.locator(".otp-digit").count()) === 5, "5 separate OTP inputs");
  ok((await reg.locator("[data-otp-sub]").textContent()).includes("+98 9131234567"), "target shown normalized", await reg.locator("[data-otp-sub]").textContent());
  ok((await reg.locator("[data-timer]").textContent()).length > 0, "resend timer visible");
  ok(await reg.locator("[data-resend]").isHidden(), "resend button hidden during countdown");
  // کد اشتباه
  await otpType(page, "register", "11111");
  await page.waitForTimeout(650);
  ok(await reg.locator("[data-otp]").evaluate(e => e.classList.contains("is-error")), "wrong code → error state");
  ok((await reg.locator("[data-otp-error]").textContent()).length > 0, "wrong code → message");
  await page.waitForTimeout(700);
  ok((await reg.locator(".otp-digit").evaluateAll(a => a.every(i => i.value === ""))), "inputs cleared after wrong code");
  ok(await reg.locator(".otp-digit").first().evaluate(e => e === document.activeElement), "focus returns to first digit");
  // Paste
  await reg.locator(".otp-digit").first().click();
  await page.evaluate(() => {
    const el = document.activeElement; const dt = new DataTransfer(); dt.setData("text", "12345");
    el.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
  });
  await reg.locator('[data-step="done"]').waitFor({ state: "visible", timeout: 4000 });
  const welcome = await reg.locator("[data-welcome]").textContent();
  ok(welcome.includes("بهنام"), "welcome uses real account name", welcome);
  await page.waitForURL(/dashboard\/projects\/new/, { timeout: 6000 }).catch(() => { });
  ok(/dashboard\/projects\/new/.test(page.url()), "returns to requested page after login (next)", page.url());
  await page.waitForSelector("[data-project-form]", { state: "visible", timeout: 4000 });
  ok(true, "logged-in user sees project form directly");

  // ---------- ۳) فرم چندمرحله‌ای ----------
  console.log("\n[3] Multi-step project form");
  await page.click("[data-next]");
  ok((await page.locator('[data-err="title"]').textContent()).length > 0, "step 1 validation blocks next");
  await page.fill("#p-title", "طراحی فروشگاه");
  await page.check('input[name="category"][value="website"]', { force: true });
  await page.fill("#p-desc", "یک فروشگاه اینترنتی با پرداخت آنلاین و پنل مدیریت");
  await page.fill("#p-goal", "افزایش فروش آنلاین");
  await page.click("[data-next]");
  ok(await page.locator('[data-step="2"]').isVisible(), "step 2 visible");
  await page.fill("#p-reqs", "سبد خرید، پرداخت، پنل ادمین");
  await page.click("[data-next]");
  await page.click("[data-next]");
  ok((await page.locator('[data-err="startWhen"]').textContent()).length > 0, "step 3 requires start/deadline");
  await page.check('input[name="startWhen"][value="asap"]', { force: true });
  await page.check('input[name="deadline"][value="4w"]', { force: true });
  await page.click("[data-next]");
  // فایل‌ها: نوع نامعتبر و معتبر
  await page.setInputFiles("[data-file-input]", { name: "evil.exe", mimeType: "application/x-msdownload", buffer: Buffer.from("MZ") });
  ok((await page.locator('[data-err="files"]').textContent()).length > 0, "invalid file type rejected");
  await page.setInputFiles("[data-file-input]", { name: "brief.pdf", mimeType: "application/pdf", buffer: Buffer.from("%PDF-1.4") });
  ok((await page.locator("[data-file-list] li").count()) === 1, "valid PDF listed with name");
  await page.setInputFiles("[data-file-input]", { name: "big.png", mimeType: "image/png", buffer: Buffer.alloc(6 * 1024 * 1024) });
  ok((await page.locator('[data-err="files"]').textContent()).length > 0, "oversize file rejected");
  await page.click("[data-file-list] .link-btn");
  ok((await page.locator("[data-file-list] li").count()) === 0, "file removable before sending");
  await page.setInputFiles("[data-file-input]", { name: "ref.png", mimeType: "image/png", buffer: Buffer.alloc(2000) });
  await page.click("[data-next]");
  ok(await page.locator("[data-review] .review-row").count() >= 10, "review summary rendered");
  await page.locator("[data-review] .review-row").first().locator("button").click();
  ok(await page.locator('[data-step="1"]').isVisible(), "edit goes back to step 1");
  await page.click("[data-next]"); await page.click("[data-next]"); await page.click("[data-next]"); await page.click("[data-next]");
  await page.click("[data-submit]");
  await page.locator("[data-wizard-success]").waitFor({ state: "visible", timeout: 4000 });
  const code1 = await page.locator("[data-track-code]").textContent();
  ok(/^BH-[A-Z2-9]{6}$/.test(code1), "tracking code generated", code1);
  ok(await page.locator("[data-project-form]").isHidden() && await page.locator("[data-stepper]").isHidden(), "wizard form/stepper hidden after success");
  ok((await page.locator("[data-ok-status]").textContent()) === "ثبت‌شده", "initial status shown");

  // ---------- ۴) پروژه‌های من و ۵) جداسازی کاربران ----------
  console.log("\n[4] My projects / isolation");
  await page.goto(`${BASE}/fa/dashboard/projects/`);
  await page.waitForSelector(".item", { timeout: 4000 });
  ok((await page.locator(".item").count()) === 1, "project listed");
  await page.locator(".item .link-btn").click();
  ok(await page.locator("[data-project-dialog]").evaluate(d => d.open), "details dialog opens");
  ok((await page.locator("[data-project-detail]").textContent()).includes(code1), "details show tracking code");
  await page.keyboard.press("Escape");
  // تغییر وضعیت (مثل پنل مدیریت) و اعلان
  await page.evaluate(c => window.__devSetProjectStatus(c, "in_progress"), code1);
  await page.reload(); await page.waitForSelector(".item");
  ok((await page.locator(".item .badge").first().textContent()) === "در حال انجام", "status change visible to owner");
  ok(await page.locator(".notif-badge").isVisible(), "notification badge shown");
  // کاربر دوم
  await page.evaluate(async () => {
    await window.AppAPI.signOut();
    await window.AppAPI.otpRequest({ purpose: "register", method: "email", target: "b@example.com", username: "second_user", displayName: "Second" });
    await window.AppAPI.otpVerify({ purpose: "register", method: "email", target: "b@example.com", code: "12345" });
  });
  const others = await page.evaluate(() => window.AppAPI.projectList());
  ok(others.length === 0, "second user cannot see first user's projects", JSON.stringify(others.length));
  await page.evaluate(() => window.AppAPI.signOut());

  // ---------- ۶) ورود با کد منقضی/بیش از حد تلاش ----------
  console.log("\n[5] Login, expired and too many attempts");
  await page.goto(`${BASE}/fa/auth/`); await page.waitForTimeout(700);
  const log = page.locator('[data-pane="login"]');
  await log.locator('[name="phone"]').fill("9139999999");
  await log.locator('button[type="submit"]').click();
  await page.waitForTimeout(600);
  ok((await log.locator('[data-status]').textContent()).length > 0, "unknown account → clear message", await log.locator('[data-status]').textContent());
  await log.locator('[name="phone"]').fill("9131234567");
  await log.locator('button[type="submit"]').click();
  await log.locator('[data-step="otp"]').waitFor({ state: "visible" });
  // منقضی کردن
  await page.evaluate(() => { const k = "bh_dev_db_v1", d = JSON.parse(localStorage.getItem(k)); Object.values(d.otp).forEach(o => o.expires = Date.now() - 1000); localStorage.setItem(k, JSON.stringify(d)); });
  await otpType(page, "login", "12345");
  await page.waitForTimeout(700);
  ok((await log.locator("[data-otp-error]").textContent()).includes("منقضی"), "expired code message");
  // ۵ تلاش اشتباه
  await page.locator('[data-pane="login"] [data-edit]').click();
  await log.locator('button[type="submit"]').click();
  await log.locator('[data-step="otp"]').waitFor({ state: "visible" });
  for (let i = 0; i < 5; i++) { await otpType(page, "login", "00000"); await page.waitForTimeout(900); }
  await otpType(page, "login", "12345"); await page.waitForTimeout(800);
  ok((await log.locator("[data-otp-error]").textContent()).includes("تلاش"), "attempt limit enforced even for correct code", await log.locator("[data-otp-error]").textContent());
  // OAuth صادقانه غیرفعال است
  await log.locator('[data-edit]').click();
  await log.locator('[data-provider="google"]').click();
  ok((await log.locator("[data-status]").textContent()).includes("Google"), "Google shows 'not enabled' (no fake login)");
  await ctx.close();

  // ---------- ۷) مشاوره: مهمان و کاربر واردشده ----------
  console.log("\n[6] Consultation");
  ({ ctx, page } = await newPage(b));
  await page.goto(`${BASE}/fa/#consult`); await page.waitForTimeout(800);
  await page.locator("#consult").scrollIntoViewIfNeeded(); await page.waitForTimeout(900);
  await page.click('[data-consult-form] button[type="submit"]');
  ok((await page.locator("#c-name-err").textContent()).length > 0, "consult validation errors");
  await page.fill("#c-name", "مهمان");
  await page.check('input[name="method"][value="email"]', { force: true });
  await page.fill("#c-value", "not-an-email");
  await page.selectOption("#c-subject", "ai");
  await page.fill("#c-text", "می‌خواهم درباره اتوماسیون مشاوره بگیرم");
  await page.click('[data-consult-form] button[type="submit"]');
  ok((await page.locator("#c-value-err").textContent()).length > 0, "invalid email rejected");
  await page.fill("#c-value", "guest@example.com");
  await page.click('[data-consult-form] button[type="submit"]');
  await page.locator("[data-consult-success]").waitFor({ state: "visible", timeout: 4000 });
  ok(true, "guest can send a consultation request (policy)");
  ok(await page.locator("[data-consult-form]").isHidden(), "form is hidden after success (no duplicate UI)");
  // کاربر واردشده: پر شدن خودکار
  await page.evaluate(async () => { await window.AppAPI.otpRequest({ purpose: "register", method: "phone", target: "+989131234567", username: "behnam_c", displayName: "بهنام" }); await window.AppAPI.otpVerify({ purpose: "register", method: "phone", target: "+989131234567", code: "12345" }); localStorage.setItem("bh_session_hint", "1"); });
  await page.goto(`${BASE}/fa/`); await page.waitForTimeout(1200);
  ok((await page.locator(".nav-cta").getAttribute("href")).includes("dashboard"), "header CTA switches to dashboard when logged in");
  ok((await page.inputValue("#c-name")) === "بهنام", "consult form prefilled from account", await page.inputValue("#c-name"));
  ok((await page.inputValue("#c-value")).includes("+98913"), "contact value prefilled");
  await ctx.close();

  // ---------- ۸) زبان، جهت، تم، لینک‌های تماس ----------
  console.log("\n[7] Language / direction / theme / contacts");
  ({ ctx, page } = await newPage(b));
  await page.goto(`${BASE}/fa/`); await page.waitForTimeout(800);
  ok(await page.evaluate(() => document.documentElement.dir === "rtl" && document.documentElement.lang === "fa"), "fa → rtl");
  await page.click(".lang-btn");
  ok(await page.locator(".lang-switch.is-open").count() === 1, "language dropdown opens");
  await page.click('.lang-item[lang="en"]');
  await page.waitForURL(/\/en\//);
  ok(await page.evaluate(() => document.documentElement.dir === "ltr" && document.documentElement.lang === "en"), "en → ltr");
  ok((await page.locator("h1").first().textContent()).includes("From idea"), "English content rendered");
  ok(await page.evaluate(() => localStorage.getItem("lang")) === "en", "language saved");
  await page.reload(); ok(/\/en\//.test(page.url()), "language kept after refresh");
  await page.goto(`${BASE}/`); await page.waitForURL(/\/en\//, { timeout: 5000 }).catch(() => { });
  ok(/\/en\//.test(page.url()), "root redirects to saved language", page.url());
  await page.goto(`${BASE}/en/auth/#register`);
  await page.click(".lang-btn"); await page.click('.lang-item[lang="fa"]');
  await page.waitForURL(/\/fa\/auth\//); ok(/#register$/.test(page.url()), "language switch keeps #register hash", page.url());
  await page.goto(`${BASE}/en/`); await page.waitForTimeout(600);
  const tel = await page.locator('[data-contact-card="phone"] a').getAttribute("href");
  ok(tel === "tel:+989130930344", "phone link is real tel:", tel);
  ok(await page.locator('[data-contact-card="telegram"] a').getAttribute("href") === null, "telegram placeholder → no fake link");
  ok(await page.locator('[data-contact-card="email"] a').getAttribute("aria-disabled") === "true", "email placeholder → disabled, no mailto");
  ok((await page.locator('[data-contact-card="email"] a').textContent()).includes("soon"), "disabled button explains state");
  await page.click(".theme-toggle");
  ok(await page.evaluate(() => document.documentElement.dataset.theme) === "dark", "theme toggles");
  ok(await page.evaluate(() => document.querySelector(".theme-toggle").getAttribute("aria-label")).then(s => /light/i.test(s)), "theme aria-label in English");
  ok(page.errs.length === 0, "no console errors", page.errs.join("|"));
  await ctx.close();

  // ---------- ۹) تنظیمات حساب ----------
  console.log("\n[8] Settings / security");
  ({ ctx, page } = await newPage(b));
  await page.goto(`${BASE}/en/auth/`);
  await page.evaluate(async () => {
    await window.AppAPI.otpRequest({ purpose: "register", method: "email", target: "s@example.com", username: "settings_user", displayName: "Sam" });
    await window.AppAPI.otpVerify({ purpose: "register", method: "email", target: "s@example.com", code: "12345" });
    localStorage.setItem("bh_session_hint", "1");
  });
  await page.goto(`${BASE}/en/dashboard/settings/#security`); await page.waitForSelector("[data-dash-inner]:not([hidden])");
  ok(await page.locator('[data-tab-panel="security"]').isVisible(), "#security opens security tab");
  await page.click('[data-tab="account"]');
  await page.fill("#s-name", "Sam W");
  await page.click("[data-profile-form] button[type=submit]");
  await page.waitForTimeout(700);
  ok((await page.locator(".user-chip-name").textContent()) === "Sam W", "display name updated");
  await page.fill("#s-user", "settings_new");
  await page.click("[data-profile-form] button[type=submit]"); await page.waitForTimeout(700);
  await page.fill("#s-user", "another_one");
  await page.click("[data-profile-form] button[type=submit]"); await page.waitForTimeout(700);
  ok((await page.locator('[data-err="username"]').textContent()).includes("30"), "username change limited (policy)", await page.locator('[data-err="username"]').textContent());
  await page.click('[data-change="phone"]'); await page.fill("#chg-value", "+989121112233");
  await page.click("[data-verify-body] button[type=submit]"); await page.waitForSelector("#chg-code");
  await page.fill("#chg-code", "00000"); await page.click("[data-verify-body] button[type=submit]"); await page.waitForTimeout(600);
  ok((await page.locator("[data-verify-body] .field-error").textContent()).length > 0, "contact change needs correct code");
  await page.fill("#chg-code", "12345"); await page.click("[data-verify-body] button[type=submit]"); await page.waitForTimeout(700);
  ok((await page.locator("[data-phone-val]").textContent()) === "+989121112233", "phone changed after verification");
  // خروج واقعی
  await page.click("[data-logout]");
  await page.waitForURL(/\/en\/$/, { timeout: 5000 }).catch(() => { });
  const sess = await page.evaluate(() => window.AppAPI.session());
  ok(sess === null, "logout ends the session");
  await page.goto(`${BASE}/en/dashboard/`); await page.waitForURL(/\/en\/auth\//, { timeout: 5000 }).catch(() => { });
  ok(/\/en\/auth\//.test(page.url()), "after logout dashboard is gated again");
  // حذف حساب
  await page.evaluate(async () => { await window.AppAPI.otpRequest({ purpose: "login", method: "email", target: "s@example.com" }); await window.AppAPI.otpVerify({ purpose: "login", method: "email", target: "s@example.com", code: "12345" }); localStorage.setItem("bh_session_hint", "1"); });
  await page.goto(`${BASE}/en/dashboard/settings/#security`); await page.waitForSelector("[data-dash-inner]:not([hidden])");
  await page.click("[data-delete-open]");
  await page.fill('[data-delete-form] [name="confirm"]', "wrong");
  await page.click('[data-delete-form] button[type=submit]');
  ok(await page.locator("[data-delete-dialog]").evaluate(d => d.open), "delete needs exact username confirmation");
  await page.fill('[data-delete-form] [name="confirm"]', "settings_new");
  await page.click('[data-delete-form] button[type=submit]'); await page.waitForTimeout(600);
  const gone = await page.evaluate(() => window.AppAPI.otpRequest({ purpose: "login", method: "email", target: "s@example.com" }).then(() => "exists", e => e.code));
  ok(gone === "ACCOUNT_NOT_FOUND", "account really deleted", gone);
  await ctx.close();

  await b.close();
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
})().catch(e => { console.error("CRASH", e.message.split("\n")[0]); process.exit(1); });

// تولید PNG و ICO از favicon.svg (یک‌بار اجرا می‌شود؛ خروجی‌ها داخل پروژه ذخیره شده‌اند)
const sharp = require("/opt/npm-tools/node_modules/sharp");
const fs = require("fs");
const svg = fs.readFileSync("favicon.svg");
(async () => {
  const out = { "apple-touch-icon.png": 180, "icon-192.png": 192, "icon-512.png": 512, "favicon-32.png": 32, "favicon-16.png": 16, "favicon-48.png": 48 };
  for (const [f, s] of Object.entries(out)) await sharp(svg, { density: 384 }).resize(s, s).png().toFile(f);
  // آیکون اپل بهتر است بدون گوشه گرد باشد (iOS خودش گرد می‌کند)
  const sq = Buffer.from(fs.readFileSync("favicon.svg", "utf8").replace('rx="15"', 'rx="0"'));
  await sharp(sq, { density: 384 }).resize(180, 180).png().toFile("apple-touch-icon.png");
  // ICO با PNG داخلی (۱۶، ۳۲، ۴۸)
  const sizes = [16, 32, 48], pngs = sizes.map(s => fs.readFileSync(`favicon-${s}.png`));
  const head = Buffer.alloc(6); head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(sizes.length, 4);
  let offset = 6 + 16 * sizes.length; const dirs = [];
  sizes.forEach((s, i) => { const d = Buffer.alloc(16); d[0] = s; d[1] = s; d.writeUInt16LE(1, 4); d.writeUInt16LE(32, 6); d.writeUInt32LE(pngs[i].length, 8); d.writeUInt32LE(offset, 12); offset += pngs[i].length; dirs.push(d); });
  fs.writeFileSync("favicon.ico", Buffer.concat([head, ...dirs, ...pngs]));
  ["favicon-16.png", "favicon-32.png", "favicon-48.png"].forEach(f => fs.unlinkSync(f));
  console.log("icons ok");
})();

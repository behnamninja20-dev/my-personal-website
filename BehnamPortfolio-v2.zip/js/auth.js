/* =========================================================
   auth.js | صفحه ACCOUNT ACCESS
   - جابه‌جایی نرم بین ورود و ثبت‌نام
   - ورود/ثبت‌نام با شماره موبایل یا ایمیل (کد تأیید ۵ رقمی)
   - دکمه‌های Google و Apple (فقط وقتی OAuth در سرور فعال باشد)
   هیچ کدی در این فایل ساخته یا بررسی نمی‌شود؛ همه‌چیز را سرور (AppAPI) تصمیم می‌گیرد.
   ========================================================= */
document.addEventListener("DOMContentLoaded", function () {
    "use strict";

    var UI = window.UI, t = window.t, api = window.AppAPI, cfg = window.SITE_CONFIG;
    var OTP_LEN = cfg.limits.otpLength;

    var card = UI.$("[data-auth]");
    var tpl = UI.$("#tpl-flow");
    var panes = UI.$$("[data-pane]", card);
    var next = UI.safeNext(new URLSearchParams(location.search).get("next"));
    var dashUrl = new URL("../dashboard/", location.href).pathname;

    function afterLogin() { location.href = next || dashUrl; }

    // ---------- وضعیت سرویس ----------
    if (api.mode === "mock") UI.$("[data-dev-banner]").hidden = false;
    if (api.mode === "none") UI.$("[data-offline-banner]").hidden = false;

    // اگر کاربر از قبل وارد شده، دوباره فرم نمی‌بیند
    if (UI.hint.get()) {
        api.session().then(function (u) { if (u) afterLogin(); }).catch(function () { });
    }

    // ============================================================
    // یک «جریان» (Flow) برای هر پنل ساخته می‌شود: مشخصات ← کد ← موفقیت
    // ============================================================
    function createFlow(pane, purpose) {
        var slot = UI.$("[data-flow-slot]", pane);
        slot.appendChild(tpl.content.cloneNode(true));
        var root = UI.$("[data-flow]", slot);

        if (purpose === "login") UI.$$('[data-only="register"]', root).forEach(function (n) { n.remove(); });

        // شناسه‌های یکتا برای ارتباط برچسب و فیلد
        UI.$$("[data-id]", root).forEach(function (i) { i.id = purpose + "-" + i.getAttribute("data-id"); });
        UI.$$("[data-for]", root).forEach(function (l) { l.setAttribute("for", purpose + "-" + l.getAttribute("data-for")); });

        var steps = {
            identity: UI.$('[data-step="identity"]', root),
            otp: UI.$('[data-step="otp"]', root),
            done: UI.$('[data-step="done"]', root)
        };
        var form = UI.$("[data-identity-form]", root);
        var statusEl = UI.$("[data-status]", form);
        var submit = UI.$('button[type="submit"]', form);
        var state = { method: "phone", country: window.COUNTRIES[0], payload: null, timer: null, busy: false };

        function show(name, focus) {
            Object.keys(steps).forEach(function (k) {
                var on = k === name;
                steps[k].hidden = !on;
                steps[k].classList.toggle("is-active", on);
            });
            if (focus === false) return;
            var f = name === "identity" ? form.querySelector("input:not([hidden])") : name === "otp" ? digits[0] : null;
            if (f) setTimeout(function () { f.focus(); }, 60);
        }

        // ---------- روش ورود: موبایل / ایمیل ----------
        var tabs = UI.$$("[data-method]", root);
        function setMethod(m) {
            state.method = m;
            tabs.forEach(function (b) { b.setAttribute("aria-selected", String(b.getAttribute("data-method") === m)); });
            UI.$$("[data-method-field]", root).forEach(function (f) { f.hidden = f.getAttribute("data-method-field") !== m; });
            submit.textContent = submit.getAttribute("data-label-" + m);
            UI.status(statusEl, "");
        }
        tabs.forEach(function (b) { b.addEventListener("click", function () { setMethod(b.getAttribute("data-method")); }); });

        // ---------- انتخاب کشور ----------
        var cBox = UI.$("[data-country]", root), cBtn = UI.$(".country-btn", cBox), cPop = UI.$(".country-pop", cBox);
        var cList = UI.$(".country-list", cBox), cSearch = UI.$(".country-search", cBox), flag = UI.$(".flag", cBox), dial = UI.$(".dial", cBox);

        function paintCountry() {
            flag.src = state.country.flag;
            flag.alt = "";
            dial.textContent = state.country.dial;
        }
        function renderCountries(q) {
            q = (q || "").toLowerCase().replace("+", "");
            cList.textContent = "";
            window.COUNTRIES.filter(function (c) {
                return !q || c.fa.indexOf(q) > -1 || c.en.toLowerCase().indexOf(q) > -1 || c.code.indexOf(q) === 0 || c.iso === q;
            }).forEach(function (c) {
                var li = document.createElement("li");
                li.setAttribute("role", "option");
                li.setAttribute("aria-selected", String(c.iso === state.country.iso));
                li.innerHTML = '<img class="flag" alt="" width="22" height="16"><span></span><span class="dial"></span>';
                li.firstChild.src = c.flag;
                li.children[1].textContent = window.LANG === "fa" ? c.fa : c.en;
                li.children[2].textContent = c.dial;
                li.addEventListener("click", function () { state.country = c; paintCountry(); toggleCountry(false); form.elements.phone.focus(); });
                cList.appendChild(li);
            });
        }
        function toggleCountry(open) {
            cPop.hidden = !open;
            cBtn.setAttribute("aria-expanded", String(open));
            if (open) { cSearch.value = ""; renderCountries(""); setTimeout(function () { cSearch.focus(); }, 30); }
        }
        cBtn.addEventListener("click", function () { toggleCountry(cPop.hidden); });
        cSearch.addEventListener("input", function () { renderCountries(cSearch.value); });
        document.addEventListener("click", function (e) { if (!cBox.contains(e.target)) toggleCountry(false); });
        cBox.addEventListener("keydown", function (e) { if (e.key === "Escape") { toggleCountry(false); cBtn.focus(); } });
        paintCountry();

        // ---------- بررسی یکتایی نام کاربری هنگام خروج از فیلد ----------
        if (purpose === "register" && api.mode !== "none") {
            form.elements.username.addEventListener("blur", function () {
                var v = form.elements.username.value.trim();
                if (!v || !UI.valid.username(v)) return;
                api.checkUsername(v).then(function (r) {
                    if (r && r.available === false) UI.fieldError(form, "username", t("err.usernameTaken"));
                }).catch(function () { });
            });
        }

        // ---------- ارسال مشخصات ----------
        function collect() {
            UI.clearErrors(form);
            var ok = true, p = { purpose: purpose, method: state.method };
            function bad(name, msg) { UI.fieldError(form, name, msg); ok = false; }

            if (purpose === "register") {
                var u = form.elements.username.value.trim();
                if (!u) bad("username", t("err.required"));
                else if (!UI.valid.username(u)) bad("username", t("err.username"));
                p.username = u;
                p.displayName = form.elements.displayName.value.trim();
            }
            if (state.method === "phone") {
                var r = window.parsePhone(state.country, form.elements.phone.value);
                if (!form.elements.phone.value.trim()) bad("phone", t("err.required"));
                else if (!r.ok) bad("phone", t("err.phone"));
                p.target = r.e164;
                p.display = state.country.dial + " " + (r.national || "");
            } else {
                var e = form.elements.email.value.trim();
                if (!e) bad("email", t("err.required"));
                else if (!UI.valid.email(e)) bad("email", t("err.email"));
                p.target = e;
                p.display = e;
            }
            return ok ? p : null;
        }

        function setBusy(b, btn) {
            state.busy = b;
            if (btn) btn.disabled = b;
        }

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            if (state.busy) return;
            var p = collect();
            if (!p) { var bad = form.querySelector('[aria-invalid="true"]'); if (bad) bad.focus(); return; }
            UI.status(statusEl, "");
            setBusy(true, submit);

            requestCode(p).then(function (res) {
                state.payload = p;
                showOtp(p, res);
            }).catch(function (err) {
                if (err.code === "USERNAME_TAKEN") UI.fieldError(form, "username", t("err.usernameTaken"));
                else if (err.code === "VALIDATION" && err.extra && err.extra.field === "username") UI.fieldError(form, "username", t("err.username"));
                else UI.status(statusEl, UI.errorMessage(err), "error");
            }).then(function () { setBusy(false, submit); });
        });

        function requestCode(p) {
            return api.otpRequest({
                purpose: p.purpose, method: p.method, target: p.target,
                username: p.username, displayName: p.displayName
            });
        }

        // ============================================================
        // کد تأیید ۵ رقمی
        // ============================================================
        var otpBox = UI.$("[data-otp]", root), otpErr = UI.$("[data-otp-error]", root);
        var verifyBtn = UI.$("[data-verify]", root), timerEl = UI.$("[data-timer]", root), resendBtn = UI.$("[data-resend]", root);
        var digits = [];

        for (var i = 0; i < OTP_LEN; i++) {
            var inp = document.createElement("input");
            inp.type = "text";
            inp.className = "otp-digit";
            inp.setAttribute("inputmode", "numeric");
            inp.setAttribute("pattern", "[0-9]*");
            inp.setAttribute("autocomplete", i === 0 ? "one-time-code" : "off");
            inp.setAttribute("aria-label", t("auth.codeAria", { i: i + 1, n: OTP_LEN }));
            inp.dataset.i = i;
            otpBox.appendChild(inp);
            digits.push(inp);
        }

        function code() { return digits.map(function (d) { return d.value; }).join(""); }

        function refresh() {
            digits.forEach(function (d) { d.classList.toggle("is-filled", !!d.value); });
            verifyBtn.disabled = code().length !== OTP_LEN || state.busy;
        }

        function clearOtp() {
            digits.forEach(function (d) { d.value = ""; });
            refresh();
        }

        function fillFrom(start, text) {
            var v = UI.normalizeDigits(text).replace(/\D/g, "");
            if (!v) return;
            for (var k = 0; k < v.length && start + k < OTP_LEN; k++) digits[start + k].value = v[k];
            digits[Math.min(start + v.length, OTP_LEN - 1)].focus();
            otpBox.classList.remove("is-error");
            otpErr.textContent = "";
            refresh();
            if (code().length === OTP_LEN) verify();
        }

        digits.forEach(function (d, idx) {
            d.addEventListener("input", function () {
                var raw = d.value;
                d.value = "";
                if (raw) fillFrom(idx, raw); else refresh();
            });
            d.addEventListener("keydown", function (e) {
                if (e.key === "Backspace" && !d.value && idx > 0) {
                    digits[idx - 1].value = ""; digits[idx - 1].focus(); refresh(); e.preventDefault();
                } else if (e.key === "ArrowLeft" && idx > 0) { digits[idx - 1].focus(); e.preventDefault(); }
                else if (e.key === "ArrowRight" && idx < OTP_LEN - 1) { digits[idx + 1].focus(); e.preventDefault(); }
                else if (e.key === "Enter") { e.preventDefault(); verify(); }
            });
            d.addEventListener("paste", function (e) {
                e.preventDefault();
                fillFrom(idx, (e.clipboardData || window.clipboardData).getData("text"));
            });
            d.addEventListener("focus", function () { d.select(); });
        });

        function showOtp(p, res) {
            UI.$("[data-otp-sub]", root).innerHTML = "";
            var sub = UI.$("[data-otp-sub]", root);
            var txt = t("auth.otpSub", { n: OTP_LEN, target: "\u0000" }).split("\u0000");
            sub.appendChild(document.createTextNode(txt[0]));
            var b = document.createElement("bdi"); b.dir = "ltr"; b.textContent = p.display; sub.appendChild(b);
            sub.appendChild(document.createTextNode(txt[1] || ""));
            clearOtp();
            otpBox.classList.remove("is-error", "is-ok", "shake");
            otpErr.textContent = "";
            startTimer((res && res.resendAfter) || cfg.limits.otpResendSeconds);
            show("otp");
        }

        // ---------- تایمر ارسال مجدد ----------
        function startTimer(sec) {
            clearInterval(state.timer);
            resendBtn.hidden = true;
            timerEl.hidden = false;
            function paint() { timerEl.textContent = t("auth.otpResendIn", { s: window.fmtNum(sec) }); }
            paint();
            state.timer = setInterval(function () {
                sec--;
                if (sec <= 0) {
                    clearInterval(state.timer);
                    timerEl.hidden = true;
                    resendBtn.hidden = false;
                } else { paint(); }
            }, 1000);
        }

        resendBtn.addEventListener("click", function () {
            if (state.busy) return;
            resendBtn.disabled = true;
            requestCode(state.payload).then(function (res) {
                UI.toast(t("auth.otpSent"));
                clearOtp();
                otpBox.classList.remove("is-error");
                otpErr.textContent = "";
                startTimer((res && res.resendAfter) || cfg.limits.otpResendSeconds);
                digits[0].focus();
            }).catch(function (err) {
                otpErr.textContent = UI.errorMessage(err);
            }).then(function () { resendBtn.disabled = false; });
        });

        UI.$("[data-edit]", root).addEventListener("click", function () {
            clearInterval(state.timer);
            show("identity");
        });

        // ---------- بررسی کد ----------
        function verify() {
            var c = code();
            if (c.length !== OTP_LEN || state.busy) return;
            setBusy(true);
            verifyBtn.disabled = true;
            otpErr.textContent = "";
            digits.forEach(function (d) { d.blur(); });

            api.otpVerify({ purpose: purpose, method: state.payload.method, target: state.payload.target, code: c })
                .then(onSuccess, onFail)
                .then(function () { setBusy(false); refresh(); });
        }
        verifyBtn.addEventListener("click", verify);

        function onFail(err) {
            otpBox.classList.add("is-error", "shake");
            otpErr.textContent = UI.errorMessage(err);
            setTimeout(function () {
                otpBox.classList.remove("shake");
                clearOtp();
                digits[0].focus();
            }, UI.reduceMotion ? 0 : 460);
        }

        function onSuccess(res) {
            var user = res.user || {};
            var name = user.displayName || user.username || "";
            clearInterval(state.timer);
            otpBox.classList.remove("is-error");
            otpBox.classList.add("is-ok");
            UI.hint.set();
            setTimeout(function () {
                UI.$("[data-welcome]", root).textContent = t(res.isNew ? "auth.welcomeNew" : "auth.welcome", { name: name });
                show("done", false);
                setTimeout(afterLogin, UI.reduceMotion ? 700 : 1900);
            }, UI.reduceMotion ? 0 : 450);
        }

        // ---------- Google / Apple ----------
        UI.$$("[data-provider]", root).forEach(function (btn) {
            btn.addEventListener("click", function () {
                var p = btn.getAttribute("data-provider"), name = p === "google" ? "Google" : "Apple";
                if (!cfg.api.oauthProviders[p] || api.mode !== "remote") {
                    UI.status(statusEl, t("err.provider", { provider: name }), "error");
                    return;
                }
                btn.disabled = true;
                api.oauthStart(p, next || dashUrl).catch(function (err) {
                    btn.disabled = false;
                    UI.status(statusEl, UI.errorMessage(err), "error");
                });
            });
        });

        // وقتی سرور متصل نیست، فرم‌ها غیرفعال می‌شوند (چیزی جعل نمی‌شود)
        if (api.mode === "none") {
            UI.$$("button, input", root).forEach(function (el) { if (el.type !== "button" || el.hasAttribute("data-provider")) el.disabled = true; });
        }

        setMethod("phone");
        show("identity", false);
        return { root: root, focus: function () { var f = form.querySelector("input:not([hidden]):not([disabled])"); if (f) f.focus(); } };
    }

    var flows = {};
    panes.forEach(function (p) { flows[p.dataset.pane] = createFlow(p, p.dataset.pane); });

    // ============================================================
    // جابه‌جایی ورود / ثبت‌نام
    // ============================================================
    function setMode(mode, focus) {
        card.dataset.mode = mode;
        UI.$$("[data-mode-btn]", card).forEach(function (b) {
            if (b.getAttribute("role") === "tab") b.setAttribute("aria-selected", String(b.getAttribute("data-mode-btn") === mode));
        });
        panes.forEach(function (p) {
            var off = p.dataset.pane !== mode;
            p.inert = off;                       // فیلدهای پنل پنهان، قابل فوکوس نیستند
            p.setAttribute("aria-hidden", String(off));
        });
        UI.$$("[data-ov]", card).forEach(function (o) { o.inert = o.dataset.ov !== mode; });
        try { history.replaceState(null, "", mode === "register" ? "#register" : location.pathname + location.search); } catch (e) { }
        if (focus) setTimeout(function () { flows[mode].focus(); }, UI.reduceMotion || window.innerWidth < 820 ? 50 : 650);
    }

    UI.$$("[data-mode-btn]", card).forEach(function (b) {
        b.addEventListener("click", function () { setMode(b.getAttribute("data-mode-btn"), true); });
    });
    window.addEventListener("hashchange", function () { setMode(location.hash === "#register" ? "register" : "login", false); });
    setMode(location.hash === "#register" ? "register" : "login", false);
});

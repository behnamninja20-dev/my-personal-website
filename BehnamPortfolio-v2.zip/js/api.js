/* =========================================================
   api.js | لایه ارتباط با سرور
   ---------------------------------------------------------
   سه حالت (آداپتور) وجود دارد:

   1) remote : وقتی SITE_CONFIG.api.baseUrl پر باشد. به API واقعی (README.md) وصل می‌شود.
   2) none   : بک‌اند متصل نیست (حالت فعلی سایت عمومی). همه عملیات‌ها خطای
               NOT_CONFIGURED می‌دهند و هیچ چیزی جعل نمی‌شود.
   3) mock   : فقط روی localhost / 127.0.0.1 / file:// برای تست رابط کاربری.
               داده‌ها فقط در localStorage همان مرورگر هستند و کد تأیید ۱۲۳۴۵ است.
               روی دامنه عمومی هرگز فعال نمی‌شود.

   تمام قوانین امنیتی واقعی (احراز هویت، مالکیت پروژه، محدودیت تلاش و ...)
   باید در سرور اعمال شوند؛ این فایل فقط واسط مرورگر است.
   ========================================================= */
(function () {
    "use strict";

    var cfg = window.SITE_CONFIG;
    var host = location.hostname;
    var isLocal = host === "" || host === "localhost" || host === "127.0.0.1" || host === "[::1]" || host === "::1";
    var mode = isLocal ? "mock" : (cfg.api.baseUrl ? "remote" : "none");

    function ApiError(code, message, extra) {
        this.name = "ApiError";
        this.code = code;
        this.message = message || code;
        this.extra = extra || {};
    }
    ApiError.prototype = Object.create(Error.prototype);

    // ------------------------------------------------------------
    // ۱) آداپتور remote
    // ------------------------------------------------------------
    var csrf = "";

    function remote(method, path, body, opts) {
        opts = opts || {};
        var ctrl = new AbortController();
        var timer = setTimeout(function () { ctrl.abort(); }, cfg.api.timeoutMs || 15000);
        var headers = { "Accept": "application/json" };
        var init = { method: method, credentials: "include", headers: headers, signal: ctrl.signal };

        if (method !== "GET" && csrf) headers["X-CSRF-Token"] = csrf;
        if (body instanceof FormData) {
            init.body = body;
        } else if (body !== undefined) {
            headers["Content-Type"] = "application/json";
            init.body = JSON.stringify(body);
        }

        return fetch(cfg.api.baseUrl.replace(/\/$/, "") + path, init).then(function (res) {
            clearTimeout(timer);
            return res.json().catch(function () { return {}; }).then(function (data) {
                if (res.ok) return data;
                var e = (data && data.error) || {};
                var code = e.code || (res.status === 401 ? "UNAUTHENTICATED" : res.status === 429 ? "RATE_LIMITED" : "SERVER");
                throw new ApiError(code, e.message, e);
            });
        }, function () {
            clearTimeout(timer);
            throw new ApiError("NETWORK");
        });
    }

    var remoteApi = {
        session: function () {
            return remote("GET", "/auth/session").then(function (d) { csrf = d.csrfToken || ""; return d.user || null; })
                .catch(function (e) { if (e.code === "UNAUTHENTICATED") return null; throw e; });
        },
        otpRequest: function (p) { return remote("POST", "/auth/otp/request", p); },
        otpVerify: function (p) { return remote("POST", "/auth/otp/verify", p).then(function (d) { csrf = d.csrfToken || csrf; return d; }); },
        oauthStart: function (provider, next) {
            location.href = cfg.api.baseUrl.replace(/\/$/, "") + "/auth/oauth/" + encodeURIComponent(provider) + "/start?next=" + encodeURIComponent(next || "");
            return new Promise(function () { });
        },
        signOut: function () { return remote("POST", "/auth/logout"); },
        signOutAll: function () { return remote("POST", "/auth/logout-all"); },
        checkUsername: function (u) { return remote("GET", "/auth/username-available?u=" + encodeURIComponent(u)); },
        profileUpdate: function (p) { return remote("PATCH", "/me", p); },
        contactChangeRequest: function (p) { return remote("POST", "/me/contact/request", p); },
        contactChangeVerify: function (p) { return remote("POST", "/me/contact/verify", p); },
        deleteAccount: function (p) { return remote("DELETE", "/me", p); },
        projectCreate: function (data, files) {
            var fd = new FormData();
            fd.append("data", JSON.stringify(data));
            (files || []).forEach(function (f) { fd.append("files", f, f.name); });
            return remote("POST", "/projects", fd);
        },
        projectList: function () { return remote("GET", "/projects").then(function (d) { return d.items || []; }); },
        consultCreate: function (p) { return remote("POST", "/consultations", p); },
        consultList: function () { return remote("GET", "/consultations").then(function (d) { return d.items || []; }); },
        notifList: function () { return remote("GET", "/notifications").then(function (d) { return d.items || []; }); },
        notifReadAll: function () { return remote("POST", "/notifications/read-all"); }
    };

    // ------------------------------------------------------------
    // ۲) آداپتور none (بک‌اند متصل نیست)
    // ------------------------------------------------------------
    function notConfigured() { return Promise.reject(new ApiError("NOT_CONFIGURED")); }

    var noneApi = {};
    Object.keys(remoteApi).forEach(function (k) { noneApi[k] = notConfigured; });
    noneApi.session = function () { return Promise.resolve(null); };   // کاربر مهمان
    noneApi.signOut = function () { return Promise.resolve({}); };

    // ------------------------------------------------------------
    // ۳) آداپتور mock (فقط توسعه محلی)
    // ------------------------------------------------------------
    var DEV_CODE = "12345";
    var KEY = "bh_dev_db_v1";

    function db() {
        try { return JSON.parse(localStorage.getItem(KEY)) || fresh(); } catch (e) { return fresh(); }
    }
    function fresh() { return { users: [], projects: [], consults: [], notifs: [], session: null, otp: {}, seq: 1 }; }
    function save(d) {
        try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) { throw new ApiError("GENERIC"); }
    }
    function later(v) { return new Promise(function (r) { setTimeout(function () { r(v); }, 350); }); }
    function fail(code, extra) { return new Promise(function (_, rej) { setTimeout(function () { rej(new ApiError(code, "", extra)); }, 350); }); }
    function clone(o) { return JSON.parse(JSON.stringify(o)); }

    function me(d) {
        var u = d.users.find(function (x) { return x.id === d.session; });
        return u || null;
    }
    function targetKey(method, target) { return method + ":" + String(target).toLowerCase(); }
    function validUsername(u) {
        return typeof u === "string" && u.length >= cfg.limits.usernameMin && u.length <= cfg.limits.usernameMax && /^[A-Za-z0-9._-]+$/.test(u);
    }
    function userByTarget(d, method, target) {
        return d.users.find(function (u) { return method === "phone" ? u.phone === target : (u.email || "").toLowerCase() === String(target).toLowerCase(); });
    }
    function trackingCode(d) {
        var abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", code;
        do {
            code = "BH-";
            for (var i = 0; i < 6; i++) code += abc[Math.floor(Math.random() * abc.length)];
        } while (d.projects.some(function (p) { return p.trackingCode === code; }));
        return code;
    }
    function pushNotif(d, userId, title, message) {
        d.notifs.push({ id: "n" + (d.seq++), userId: userId, title: title, message: message, readAt: null, createdAt: new Date().toISOString() });
    }

    var mockApi = {
        session: function () { return later(me(db())).then(function (u) { return u ? clone(u) : null; }); },

        otpRequest: function (p) {
            var d = db(), key = targetKey(p.method, p.target);
            var exists = !!userByTarget(d, p.method, p.target);
            if (p.purpose === "login" && !exists) return fail("ACCOUNT_NOT_FOUND");
            if (p.purpose === "register" && exists) return fail("ACCOUNT_EXISTS");
            if (p.purpose === "register") {
                if (!validUsername(p.username)) return fail("VALIDATION", { field: "username" });
                if (d.users.some(function (u) { return u.username.toLowerCase() === p.username.toLowerCase(); })) return fail("USERNAME_TAKEN");
            }
            var rec = d.otp[key] || { sends: 0 };
            if (rec.sends >= 5) return fail("RATE_LIMITED");
            d.otp[key] = { code: DEV_CODE, expires: Date.now() + 5 * 60 * 1000, attempts: 0, sends: rec.sends + 1, ctx: p };
            save(d);
            return later({ resendAfter: cfg.limits.otpResendSeconds, expiresIn: 300 });
        },

        otpVerify: function (p) {
            var d = db(), key = targetKey(p.method, p.target), rec = d.otp[key];
            if (!rec) return fail("CODE_EXPIRED");
            if (rec.attempts >= 5) return fail("TOO_MANY_ATTEMPTS");
            if (Date.now() > rec.expires) { delete d.otp[key]; save(d); return fail("CODE_EXPIRED"); }
            if (String(p.code) !== rec.code) { rec.attempts++; save(d); return fail("INVALID_CODE"); }

            var ctx = rec.ctx, user = userByTarget(d, p.method, p.target), isNew = false;
            delete d.otp[key];
            if (p.purpose === "register") {
                if (user) return fail("ACCOUNT_EXISTS");
                isNew = true;
                user = {
                    id: "u" + (d.seq++), username: ctx.username, displayName: ctx.displayName || ctx.username,
                    email: p.method === "email" ? p.target : "", phone: p.method === "phone" ? p.target : "",
                    avatar: "", createdAt: new Date().toISOString(), status: "active", usernameChangedAt: null,
                    providers: { phone: p.method === "phone", email: p.method === "email", google: false, apple: false }
                };
                d.users.push(user);
            } else if (!user) {
                return fail("ACCOUNT_NOT_FOUND");
            }
            d.session = user.id;
            save(d);
            return later({ user: clone(user), isNew: isNew });
        },

        oauthStart: function () { return fail("PROVIDER_DISABLED"); },
        signOut: function () { var d = db(); d.session = null; save(d); return later({}); },
        signOutAll: function () { var d = db(); d.session = null; save(d); return later({}); },

        checkUsername: function (u) {
            var d = db(), mine = me(d);
            var taken = d.users.some(function (x) { return x.username.toLowerCase() === u.toLowerCase() && (!mine || x.id !== mine.id); });
            return later({ available: !taken });
        },

        profileUpdate: function (p) {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            if (p.username !== undefined && p.username !== u.username) {
                if (!validUsername(p.username)) return fail("VALIDATION", { field: "username" });
                if (d.users.some(function (x) { return x.id !== u.id && x.username.toLowerCase() === p.username.toLowerCase(); })) return fail("USERNAME_TAKEN");
                var days = cfg.limits.usernameChangeDays;
                if (u.usernameChangedAt && Date.now() - new Date(u.usernameChangedAt).getTime() < days * 864e5) return fail("USERNAME_LOCKED", { days: days });
                u.username = p.username; u.usernameChangedAt = new Date().toISOString();
            }
            if (p.displayName !== undefined) u.displayName = String(p.displayName).slice(0, 60) || u.username;
            if (p.avatar !== undefined) u.avatar = p.avatar;
            save(d);
            return later(clone(u));
        },

        contactChangeRequest: function (p) {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            if (userByTarget(d, p.method, p.target)) return fail("ACCOUNT_EXISTS");
            d.otp["chg:" + targetKey(p.method, p.target)] = { code: DEV_CODE, expires: Date.now() + 5 * 60 * 1000, attempts: 0 };
            save(d);
            return later({ resendAfter: cfg.limits.otpResendSeconds });
        },
        contactChangeVerify: function (p) {
            var d = db(), u = me(d), key = "chg:" + targetKey(p.method, p.target), rec = d.otp[key];
            if (!u) return fail("UNAUTHENTICATED");
            if (!rec || Date.now() > rec.expires) return fail("CODE_EXPIRED");
            if (String(p.code) !== rec.code) { rec.attempts++; save(d); return fail(rec.attempts >= 5 ? "TOO_MANY_ATTEMPTS" : "INVALID_CODE"); }
            delete d.otp[key];
            if (p.method === "phone") { u.phone = p.target; u.providers.phone = true; } else { u.email = p.target; u.providers.email = true; }
            save(d);
            return later(clone(u));
        },

        deleteAccount: function (p) {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            if (p.confirm !== u.username) return fail("VALIDATION", { field: "confirm" });
            d.users = d.users.filter(function (x) { return x.id !== u.id; });
            d.projects = d.projects.filter(function (x) { return x.ownerId !== u.id; });
            d.consults = d.consults.filter(function (x) { return x.ownerId !== u.id; });
            d.notifs = d.notifs.filter(function (x) { return x.userId !== u.id; });
            d.session = null;
            save(d);
            return later({});
        },

        projectCreate: function (data, files) {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");           // مثل سرور: بدون ورود ثبت نمی‌شود
            var p = Object.assign({}, data, {
                id: "p" + (d.seq++), ownerId: u.id, trackingCode: trackingCode(d), status: "submitted",
                createdAt: new Date().toISOString(),
                files: (files || []).map(function (f) { return { name: f.name, size: f.size, type: f.type }; })
            });
            d.projects.push(p);
            pushNotif(d, u.id, "submitted", p.trackingCode);
            save(d);
            return later(clone(p));
        },
        projectList: function () {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            return later(clone(d.projects.filter(function (p) { return p.ownerId === u.id; }).reverse()));
        },

        consultCreate: function (p) {
            var d = db(), u = me(d);
            var c = Object.assign({}, p, { id: "c" + (d.seq++), ownerId: u ? u.id : null, status: "submitted", createdAt: new Date().toISOString() });
            d.consults.push(c);
            save(d);
            return later(clone(c));
        },
        consultList: function () {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            return later(clone(d.consults.filter(function (c) { return c.ownerId === u.id; }).reverse()));
        },

        notifList: function () {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            return later(clone(d.notifs.filter(function (n) { return n.userId === u.id; }).reverse()));
        },
        notifReadAll: function () {
            var d = db(), u = me(d);
            if (!u) return fail("UNAUTHENTICATED");
            d.notifs.forEach(function (n) { if (n.userId === u.id && !n.readAt) n.readAt = new Date().toISOString(); });
            save(d);
            return later({});
        }
    };

    // ابزار تست محلی: تغییر وضعیت یک پروژه (مثل کاری که پنل مدیریت سرور انجام می‌دهد)
    if (mode === "mock") {
        window.__devSetProjectStatus = function (code, status) {
            var d = db(), p = d.projects.find(function (x) { return x.trackingCode === code; });
            if (!p) return false;
            p.status = status;
            pushNotif(d, p.ownerId, "status:" + status, p.trackingCode);
            save(d);
            return true;
        };
    }

    window.AppAPI = { mode: mode, ApiError: ApiError, devCode: DEV_CODE };
    var impl = mode === "remote" ? remoteApi : mode === "mock" ? mockApi : noneApi;
    Object.keys(impl).forEach(function (k) { window.AppAPI[k] = impl[k]; });
})();

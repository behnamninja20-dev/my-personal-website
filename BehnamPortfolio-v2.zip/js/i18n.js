/* =========================================================
   i18n.js | ترجمه در مرورگر
   دیکشنری زبان (window.I18N) از فایل i18n/fa.js یا i18n/en.js می‌آید
   و از یک منبع مرکزی ساخته می‌شود (i18n/fa.json و i18n/en.json).
   ========================================================= */
(function () {
    "use strict";

    var dict = window.I18N || {};
    var lang = document.documentElement.lang === "en" ? "en" : "fa";

    // t("auth.welcome", { name: "Ali" }) ← جایگزینی {name}
    window.t = function (key, vars) {
        var s = Object.prototype.hasOwnProperty.call(dict, key) ? dict[key] : key;
        if (vars) {
            s = s.replace(/\{(\w+)\}/g, function (m, k) {
                return vars[k] !== undefined ? vars[k] : m;
            });
        }
        return s;
    };

    window.LANG = lang;

    // تاریخ: فارسی با تقویم شمسی، انگلیسی با میلادی
    window.fmtDate = function (iso) {
        if (!iso) return "—";
        try {
            return new Intl.DateTimeFormat(lang === "fa" ? "fa-IR-u-ca-persian" : "en-GB", { dateStyle: "medium" })
                .format(new Date(iso));
        } catch (e) { return String(iso).slice(0, 10); }
    };

    window.fmtNum = function (n) {
        try { return new Intl.NumberFormat(lang === "fa" ? "fa-IR" : "en-US").format(n); } catch (e) { return String(n); }
    };
})();

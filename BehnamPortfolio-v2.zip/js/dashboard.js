/* =========================================================
   dashboard.js | پنل کاربری
   ---------------------------------------------------------
   - قبل از نمایش هر صفحه، ورود کاربر از سرور پرسیده می‌شود (گیت ورود).
     این فقط برای تجربه کاربری است؛ دسترسی واقعی را سرور کنترل می‌کند.
   - همه متن‌هایی که از کاربر می‌آیند با textContent درج می‌شوند (جلوگیری از XSS).
   ========================================================= */
document.addEventListener("DOMContentLoaded", function () {
    "use strict";

    var UI = window.UI, t = window.t, api = window.AppAPI, cfg = window.SITE_CONFIG, L = cfg.limits;
    var $ = UI.$, $$ = UI.$$;

    var pageEl = $("[data-dash-page]");
    var page = pageEl.getAttribute("data-dash-page");
    var dash = $("[data-dash]");
    var stateBox = $("[data-dash-state]"), inner = $("[data-dash-inner]");
    var stateText = $("[data-dash-state-text]"), stateLink = $("[data-dash-state-link]"), retryBtn = $("[data-dash-retry]");
    var authHref = stateLink.getAttribute("href");
    var user = null;

    // ---------- کمکی‌ها ----------
    function h(tag, props, kids) {
        var el = document.createElement(tag);
        Object.keys(props || {}).forEach(function (k) {
            if (k === "class") el.className = props[k];
            else if (k === "text") el.textContent = props[k];
            else el.setAttribute(k, props[k]);
        });
        (kids || []).forEach(function (c) { if (c) el.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
        return el;
    }

    function badge(status, kind) {
        var key = (kind === "c" ? "cstatus." : "status.") + status;
        return h("span", { class: "badge badge-" + status, text: t(key) });
    }

    function paintAvatar(el, u) {
        if (u.avatar) { el.style.backgroundImage = "url(" + JSON.stringify(u.avatar) + ")"; el.textContent = ""; }
        else { el.style.backgroundImage = ""; el.textContent = (u.displayName || u.username || "?").trim().charAt(0).toUpperCase(); }
    }

    function paintUser() {
        $$("[data-avatar]").forEach(function (e) { paintAvatar(e, user); });
        $$("[data-display-name]").forEach(function (e) { e.textContent = user.displayName || user.username; });
        $("[data-user-chip]").hidden = false;
    }

    function gateRedirect() {
        var back = location.pathname + location.search + location.hash;
        location.replace(authHref + "?next=" + encodeURIComponent(back));
    }

    function showError(err) {
        stateText.textContent = err && err.code === "NETWORK" ? t("err.network") : t("dash.loadError");
        retryBtn.hidden = false;
    }

    function empty(msg, ctaText, ctaHref) {
        var box = h("div", { class: "empty" }, [h("p", { text: msg })]);
        if (ctaText) box.appendChild(h("a", { class: "btn btn-primary", href: ctaHref, text: ctaText }));
        return box;
    }

    function projectUrl() { return $('[data-nav="projects"]').getAttribute("href"); }
    function newUrl() { return $('[data-nav="project-new"]').getAttribute("href"); }
    function homeUrl() { return $(".dash-link").getAttribute("href"); }

    // ============================================================
    // شروع: گیت ورود
    // ============================================================
    function boot() {
        retryBtn.hidden = true;
        stateText.textContent = t("common.loading");
        api.session().then(function (u) {
            if (!u) { UI.hint.clear(); gateRedirect(); return; }
            user = u;
            UI.hint.set();
            stateBox.hidden = true;
            inner.hidden = false;
            paintUser();
            initChrome();
            (modules[page] || function () { })();
        }).catch(showError);
    }
    retryBtn.addEventListener("click", boot);

    // ============================================================
    // قاب پنل: منو، اعلان‌ها، خروج
    // ============================================================
    function initChrome() {
        // منوی فعال
        var active = page === "overview" ? "dashboard" : page === "settings" && location.hash === "#security" ? "security" : page;
        $$("[data-nav]").forEach(function (a) { a.classList.toggle("is-active", a.getAttribute("data-nav") === active); });

        // منوی کشویی (موبایل)
        var burger = $("[data-dash-toggle]"), scrim = $("[data-dash-scrim]");
        function setOpen(o) {
            dash.classList.toggle("is-open", o);
            burger.setAttribute("aria-expanded", String(o));
            document.body.style.overflow = o ? "hidden" : "";
            if (o) { var f = $(".dash-nav a"); if (f) setTimeout(function () { f.focus(); }, 80); } else if (document.activeElement && $("#dash-side").contains(document.activeElement)) burger.focus();
        }
        burger.addEventListener("click", function () { setOpen(!dash.classList.contains("is-open")); });
        scrim.addEventListener("click", function () { setOpen(false); });
        $$(".dash-nav a").forEach(function (a) { a.addEventListener("click", function () { setOpen(false); }); });
        document.addEventListener("keydown", function (e) { if (e.key === "Escape") setOpen(false); });
        window.matchMedia("(min-width: 901px)").addEventListener("change", function (e) { if (e.matches) setOpen(false); });

        // خروج: نشست در سرور بسته می‌شود
        $("[data-logout]").addEventListener("click", function () {
            api.signOut().catch(function () { }).then(function () { UI.hint.clear(); location.href = homeUrl(); });
        });

        initNotifications();
    }

    // ---------- اعلان‌ها ----------
    var notifCache = [];
    function notifText(n) {
        if (n.title === "submitted") return { title: t("form.okTitle"), msg: n.message };
        if (/^status:/.test(n.title)) return { title: t("status." + n.title.slice(7)), msg: n.message };
        return { title: n.title, msg: n.message };
    }
    function renderNotifs(into) {
        into.textContent = "";
        if (!notifCache.length) { into.appendChild(h("p", { class: "muted small", text: t("dash.notifsEmpty") })); return; }
        notifCache.slice(0, 20).forEach(function (n) {
            var x = notifText(n);
            into.appendChild(h("div", { class: "notif-item" + (n.readAt ? "" : " is-unread") }, [
                h("strong", { text: x.title }), h("span", { text: x.msg }), h("span", { class: "small", text: window.fmtDate(n.createdAt) })
            ]));
        });
    }
    function initNotifications() {
        var box = $("[data-notif]"), btn = $(".notif-btn", box), pop = $(".notif-pop", box), list = $("[data-notif-list]", box), badgeEl = $(".notif-badge", box);
        function paint() {
            badgeEl.hidden = !notifCache.some(function (n) { return !n.readAt; });
            renderNotifs(list);
            var pl = $("[data-notif-page-list]");
            if (pl) renderNotifs(pl);
        }
        api.notifList().then(function (items) { notifCache = items; paint(); }).catch(function () { paint(); });
        function toggle(o) { pop.hidden = !o; btn.setAttribute("aria-expanded", String(o)); }
        btn.addEventListener("click", function (e) { e.stopPropagation(); toggle(pop.hidden); });
        document.addEventListener("click", function (e) { if (!box.contains(e.target)) toggle(false); });
        document.addEventListener("keydown", function (e) { if (e.key === "Escape") toggle(false); });
        $("[data-notif-readall]", box).addEventListener("click", function () {
            api.notifReadAll().then(function () {
                notifCache.forEach(function (n) { n.readAt = n.readAt || new Date().toISOString(); });
                paint();
            }).catch(function (e) { UI.toast(UI.errorMessage(e), "error"); });
        });
    }

    // ---------- دیالوگ‌ها ----------
    $$("dialog").forEach(function (d) {
        d.addEventListener("click", function (e) { if (e.target === d) d.close(); });
        $$("[data-dialog-close]", d).forEach(function (b) { b.addEventListener("click", function () { d.close(); }); });
    });

    // ============================================================
    // صفحه‌ها
    // ============================================================
    var modules = {};

    // ---------- نمای کلی ----------
    modules.overview = function () {
        $("[data-hello]").textContent = t("dash.hello", { name: user.displayName || user.username });
        $("[data-account-status]").textContent = t("dash.status." + (user.status === "suspended" ? "suspended" : "active"));
        $("[data-username]").textContent = user.username;

        api.projectList().then(function (items) {
            var active = items.filter(function (p) { return ["approved", "in_progress"].indexOf(p.status) > -1; }).length;
            var done = items.filter(function (p) { return p.status === "completed"; }).length;
            $('[data-stat="total"]').textContent = window.fmtNum(items.length);
            $('[data-stat="active"]').textContent = window.fmtNum(active);
            $('[data-stat="done"]').textContent = window.fmtNum(done);

            var box = $("[data-recent-list]");
            box.textContent = "";
            if (!items.length) { box.appendChild(empty(t("proj.empty"), t("proj.emptyCta"), newUrl())); return; }
            items.slice(0, 4).forEach(function (p) {
                box.appendChild(h("div", { class: "mini-item" }, [h("strong", { text: p.title }), badge(p.status)]));
            });
        }).catch(function (e) { $("[data-recent-list]").appendChild(h("p", { class: "field-error", text: UI.errorMessage(e) })); });
    };

    // ---------- پروژه‌های من ----------
    function detailRows(p) {
        var none = t("form.none");
        var rows = [
            ["proj.code", p.trackingCode], ["proj.status", null, badge(p.status)], ["proj.date", window.fmtDate(p.createdAt)],
            ["proj.category", t("cat." + p.category)], ["proj.desc", p.description], ["proj.goal", p.goal],
            ["proj.reqs", p.requirements], ["proj.audience", p.audience || none], ["proj.refs", p.references || none],
            ["proj.assets", (p.assets && p.assets.length ? p.assets.map(function (a) { return t("asset." + a); }).join("، ") : none)],
            ["proj.budget", p.budget || none], ["proj.start", t("start." + p.startWhen)], ["proj.deadline", t("dl." + p.deadline)],
            ["proj.priority", t("prio." + p.priority)],
            ["proj.files", p.files && p.files.length ? p.files.map(function (f) { return f.name; }).join("\n") : none]
        ];
        var dl = h("dl", { class: "dl-grid" });
        rows.forEach(function (r) {
            var dd = h("dd", r[1] !== null ? { text: r[1] } : {});
            if (r[2]) dd.appendChild(r[2]);
            if (r[0] === "proj.code") dd.setAttribute("dir", "ltr");
            dl.appendChild(h("div", {}, [h("dt", { text: t(r[0]) }), dd]));
        });
        return dl;
    }

    modules.projects = function () {
        var box = $("[data-projects-list]"), dlg = $("[data-project-dialog]");
        box.appendChild(h("p", { class: "muted", text: t("common.loading") }));
        api.projectList().then(function (items) {
            box.textContent = "";
            if (!items.length) { box.appendChild(empty(t("proj.empty"), t("proj.emptyCta"), newUrl())); return; }
            items.forEach(function (p) {
                var btn = h("button", { class: "link-btn", type: "button", text: t("proj.details") });
                btn.addEventListener("click", function () {
                    $("#pd-title").textContent = p.title;
                    var body = $("[data-project-detail]");
                    body.textContent = "";
                    body.appendChild(detailRows(p));
                    dlg.showModal();
                });
                box.appendChild(h("article", { class: "item" }, [
                    h("div", { class: "item-top" }, [h("h2", { class: "item-title", text: p.title }), badge(p.status)]),
                    h("div", { class: "item-meta" }, [
                        h("span", {}, [t("proj.code") + ": ", h("bdi", { dir: "ltr", text: p.trackingCode })]),
                        h("span", { text: t("proj.date") + ": " + window.fmtDate(p.createdAt) }),
                        h("span", { text: t("cat." + p.category) })
                    ]),
                    h("p", { class: "item-desc", text: p.description }), btn
                ]));
            });
        }).catch(function (e) { box.textContent = ""; box.appendChild(h("p", { class: "field-error", text: UI.errorMessage(e) })); });
    };

    // ---------- درخواست‌های مشاوره ----------
    modules.consults = function () {
        var box = $("[data-consults-list]");
        api.consultList().then(function (items) {
            box.textContent = "";
            if (!items.length) { box.appendChild(empty(t("cons.empty"), t("cons.emptyCta"), homeUrl() + "#consult")); return; }
            items.forEach(function (c) {
                box.appendChild(h("article", { class: "item" }, [
                    h("div", { class: "item-top" }, [h("h2", { class: "item-title", text: t("topic." + c.subject) }), badge(c.status, "c")]),
                    h("div", { class: "item-meta" }, [
                        h("span", { text: window.fmtDate(c.createdAt) }),
                        h("span", {}, [t("consult.m." + c.method) + ": ", h("bdi", { dir: "ltr", text: c.value })]),
                        h("span", { text: t("consult.t." + c.time) })
                    ]),
                    h("p", { class: "item-desc", text: c.text })
                ]));
            });
        }).catch(function (e) { box.appendChild(h("p", { class: "field-error", text: UI.errorMessage(e) })); });
    };

    // ============================================================
    // فرم چندمرحله‌ای ثبت پروژه
    // ============================================================
    modules["project-new"] = function () {
        var wiz = $("[data-wizard]"), form = $("[data-project-form]"), TOTAL = 5, cur = 1;
        var stepEls = $$(".wstep", form), inds = $$("[data-step-ind]", wiz);
        var prev = $("[data-prev]", form), nextBtn = $("[data-next]", form), submit = $("[data-submit]", form);
        var statusEl = $("[data-form-status]", form), counter = $("[data-step-counter]", wiz);
        var files = [];

        $("[data-files-hint]").textContent = t("form.filesHint", { n: L.maxFiles, mb: L.fileMaxMB });

        function val(name) { return (form.elements[name].value || "").trim(); }
        function checked(name) {
            var r = form.querySelector('input[name="' + name + '"]:checked');
            return r ? r.value : "";
        }

        function go(n) {
            cur = n;
            stepEls.forEach(function (s) {
                var on = Number(s.getAttribute("data-step")) === n;
                s.hidden = !on;
                if (on && !UI.reduceMotion) { s.classList.remove("is-entering"); void s.offsetWidth; s.classList.add("is-entering"); }
            });
            inds.forEach(function (li) {
                var i = Number(li.getAttribute("data-step-ind"));
                li.classList.toggle("is-current", i === n);
                li.classList.toggle("is-done", i < n);
                if (i === n) li.setAttribute("aria-current", "step"); else li.removeAttribute("aria-current");
            });
            counter.textContent = t("form.step", { i: window.fmtNum(n), n: window.fmtNum(TOTAL) }) + " — " + t("form.s" + n);
            prev.hidden = n === 1;
            nextBtn.hidden = n === TOTAL;
            submit.hidden = n !== TOTAL;
            UI.status(statusEl, "");
            if (n === TOTAL) renderReview();
            var first = $('[data-step="' + n + '"] input:not([type=hidden]):not(.sr-only), [data-step="' + n + '"] textarea', form);
            if (first && n < 5) setTimeout(function () { first.focus({ preventScroll: true }); }, 40);
            wiz.scrollIntoView({ behavior: UI.reduceMotion ? "auto" : "smooth", block: "start" });
        }

        function validate(n) {
            var ok = true;
            function bad(name, msg) { UI.fieldError(form, name, msg); ok = false; }
            function need(name, min) {
                var v = val(name);
                UI.fieldError(form, name, "");
                if (!v) bad(name, t("err.required"));
                else if (v.length < min) bad(name, t("err.minLen", { n: min }));
            }
            if (n === 1) {
                need("title", 3);
                UI.fieldError(form, "category", "");
                if (!checked("category")) bad("category", t("err.required"));
                need("description", 20);
                need("goal", 10);
            }
            if (n === 2) need("requirements", 10);
            if (n === 3) {
                ["startWhen", "deadline"].forEach(function (k) {
                    UI.fieldError(form, k, "");
                    if (!checked(k)) bad(k, t("err.required"));
                });
            }
            if (!ok) {
                var f = form.querySelector('[data-step="' + n + '"] [aria-invalid="true"]') || form.querySelector('[data-step="' + n + '"] .field-error:not(:empty)');
                if (f) { f.focus && f.focus(); if (!f.focus) f.scrollIntoView({ block: "center" }); }
            }
            return ok;
        }

        function collect() {
            return {
                title: val("title"), category: checked("category"), description: val("description"), goal: val("goal"),
                requirements: val("requirements"), audience: val("audience"), references: val("references"),
                assets: $$('input[name="assets"]:checked', form).map(function (i) { return i.value; }),
                budget: val("budget"), startWhen: checked("startWhen"), deadline: checked("deadline"), priority: checked("priority") || "normal"
            };
        }

        // ---------- بازبینی ----------
        function reviewRows(d) {
            var none = t("form.none");
            return [
                ["form.projTitle", d.title, 1], ["form.type", t("cat." + d.category), 1], ["form.desc", d.description, 1], ["form.goal", d.goal, 1],
                ["form.reqs", d.requirements, 2], ["form.audience", d.audience || none, 2], ["form.refs", d.references || none, 2],
                ["form.assets", d.assets.length ? d.assets.map(function (a) { return t("asset." + a); }).join("، ") : none, 2],
                ["form.budget", d.budget || none, 3], ["form.startWhen", t("start." + d.startWhen), 3], ["form.deadline", t("dl." + d.deadline), 3],
                ["form.priority", t("prio." + d.priority), 3],
                ["form.filesTitle", files.length ? files.map(function (f) { return f.name; }).join("\n") : none, 4]
            ];
        }
        function renderReview() {
            var box = $("[data-review]", form);
            box.textContent = "";
            reviewRows(collect()).forEach(function (r) {
                var edit = h("button", { type: "button", class: "link-btn", text: t("common.edit") });
                edit.addEventListener("click", function () { go(r[2]); });
                box.appendChild(h("div", { class: "review-row" }, [h("dt", { text: t(r[0]) }), h("dd", { text: r[1] }), edit]));
            });
        }

        // ---------- فایل‌ها ----------
        var OK_TYPES = ["image/jpeg", "image/png", "image/webp", "application/pdf"];
        function sizeText(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB"; }

        function renderFiles() {
            var ul = $("[data-file-list]", form);
            ul.textContent = "";
            files.forEach(function (f, i) {
                var rm = h("button", { type: "button", class: "link-btn", text: t("common.remove"), "aria-label": t("common.remove") + " " + f.name });
                rm.addEventListener("click", function () { files.splice(i, 1); renderFiles(); UI.fieldError(form, "files", ""); });
                ul.appendChild(h("li", {}, [h("span", { class: "fname", text: f.name }), h("span", { class: "fsize", text: sizeText(f.size) }), rm]));
            });
        }
        function addFiles(list) {
            var err = "";
            Array.prototype.forEach.call(list, function (f) {
                if (OK_TYPES.indexOf(f.type) < 0) { err = t("err.fileType"); return; }
                if (f.size > L.fileMaxMB * 1048576) { err = t("err.fileSize", { mb: L.fileMaxMB }); return; }
                if (files.length >= L.maxFiles) { err = t("err.fileCount", { n: L.maxFiles }); return; }
                if (files.some(function (x) { return x.name === f.name && x.size === f.size && x.lastModified === f.lastModified; })) return;
                files.push(f);
            });
            UI.fieldError(form, "files", err);
            renderFiles();
        }
        var fin = $("[data-file-input]", form), dz = $("[data-dropzone]", form);
        fin.addEventListener("change", function () { addFiles(fin.files); fin.value = ""; });
        ["dragenter", "dragover"].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.add("is-over"); }); });
        ["dragleave", "drop"].forEach(function (ev) { dz.addEventListener(ev, function (e) { e.preventDefault(); dz.classList.remove("is-over"); }); });
        dz.addEventListener("drop", function (e) { addFiles(e.dataTransfer.files); });

        // ---------- ناوبری ----------
        nextBtn.addEventListener("click", function () { if (validate(cur)) go(cur + 1); });
        prev.addEventListener("click", function () { go(cur - 1); });
        // Enter در فیلدهای تک‌خطی فرم را ارسال نکند؛ به مرحله بعد برود
        form.addEventListener("keydown", function (e) {
            if (e.key === "Enter" && e.target.tagName === "INPUT" && e.target.type !== "file") {
                e.preventDefault();
                if (cur < TOTAL) { if (validate(cur)) go(cur + 1); }
            }
        });
        $$("input,textarea", form).forEach(function (i) { i.addEventListener("input", function () { UI.fieldError(form, i.name, ""); }); });

        // ---------- ارسال ----------
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            if (cur !== TOTAL) return;
            for (var s = 1; s <= 3; s++) { if (!validate(s)) { go(s); return; } }   // اعتبارسنجی دوباره همه مرحله‌ها
            var data = collect();
            submit.disabled = true;
            submit.textContent = submit.getAttribute("data-busy");
            UI.status(statusEl, "");

            api.projectCreate(data, files).then(function (res) {
                $("[data-track-code]").textContent = res.trackingCode;
                $("[data-track-code]").setAttribute("data-allow-copy", "");
                var b = $("[data-ok-status]");
                b.className = "badge badge-" + res.status;
                b.textContent = t("status." + res.status);
                var sum = $("[data-ok-summary]");
                sum.textContent = "";
                reviewRows(data).slice(0, 4).forEach(function (r) {
                    sum.appendChild(h("div", { class: "review-row" }, [h("dt", { text: t(r[0]) }), h("dd", { text: r[1] })]));
                });
                form.hidden = true;
                $("[data-stepper]", wiz).hidden = true;
                counter.hidden = true;
                $("[data-wizard-success]").hidden = false;
                $("[data-wizard-success] h2").setAttribute("tabindex", "-1");
                $("[data-wizard-success] h2").focus();
            }).catch(function (err) {
                if (err.code === "UNAUTHENTICATED") { gateRedirect(); return; }
                UI.status(statusEl, UI.errorMessage(err), "error");
            }).then(function () {
                submit.disabled = false;
                submit.textContent = submit.getAttribute("data-label");
            });
        });

        $("[data-copy-code]").addEventListener("click", function () {
            var code = $("[data-track-code]").textContent;
            (navigator.clipboard ? navigator.clipboard.writeText(code) : Promise.reject()).then(function () { UI.toast(t("common.copied")); }, function () { UI.toast(code); });
        });

        $("[data-another]").addEventListener("click", function () {
            form.reset(); files = []; renderFiles();
            form.hidden = false;
            $("[data-stepper]", wiz).hidden = false;
            counter.hidden = false;
            $("[data-wizard-success]").hidden = true;
            go(1);
        });

        go(1);
        window.scrollTo(0, 0);
    };

    // ============================================================
    // تنظیمات و امنیت حساب
    // ============================================================
    modules.settings = function () {
        var form = $("[data-profile-form]"), statusEl = $("[data-status]", form);

        // ---------- تب‌ها ----------
        function tab(name) {
            $$("[data-tab]").forEach(function (b) { b.setAttribute("aria-selected", String(b.getAttribute("data-tab") === name)); });
            $$("[data-tab-panel]").forEach(function (p) { p.hidden = p.getAttribute("data-tab-panel") !== name; });
            $$("[data-nav]").forEach(function (a) { a.classList.toggle("is-active", a.getAttribute("data-nav") === (name === "security" ? "security" : "settings")); });
            try { history.replaceState(null, "", name === "security" ? "#security" : location.pathname + location.search); } catch (e) { }
        }
        $$("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { tab(b.getAttribute("data-tab")); }); });
        window.addEventListener("hashchange", function () { tab(location.hash === "#security" ? "security" : "account"); });
        tab(location.hash === "#security" ? "security" : "account");

        // ---------- نمایش اطلاعات ----------
        function fill() {
            form.elements.displayName.value = user.displayName || "";
            form.elements.username.value = user.username || "";
            $("[data-username-hint]").textContent = t("set.usernameHint", { d: L.usernameChangeDays });
            $("[data-email-val]").textContent = user.email || t("set.notSet");
            $("[data-phone-val]").textContent = user.phone || t("set.notSet");
            paintUser();
            var ml = $("[data-methods-list]");
            ml.textContent = "";
            [["phone", t("auth.tab.phone")], ["email", t("auth.tab.email")], ["google", "Google"], ["apple", "Apple"]].forEach(function (m) {
                var on = !!(user.providers && user.providers[m[0]]) || (m[0] === "phone" && user.phone) || (m[0] === "email" && user.email);
                ml.appendChild(h("li", {}, [h("span", { class: "kv-k", text: m[1] }), h("span", { class: "kv-v" }, [h("span", { class: "badge badge-" + (on ? "completed" : "closed"), text: on ? t("sec.connected") : t("sec.notConnected") })])]));
            });
        }
        fill();

        // ---------- ذخیره پروفایل ----------
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            UI.clearErrors(form);
            var name = form.elements.displayName.value.trim(), uname = form.elements.username.value.trim();
            if (!uname || !UI.valid.username(uname)) { UI.fieldError(form, "username", t("err.username")); form.elements.username.focus(); return; }
            var patch = { displayName: name || uname };
            if (uname !== user.username) patch.username = uname;
            var btn = $('button[type="submit"]', form);
            btn.disabled = true;
            api.profileUpdate(patch).then(function (u) {
                user = u; fill(); UI.status(statusEl, t("common.saved"), "ok");
            }).catch(function (err) {
                if (err.code === "USERNAME_TAKEN") UI.fieldError(form, "username", t("err.usernameTaken"));
                else if (err.code === "USERNAME_LOCKED") UI.fieldError(form, "username", UI.errorMessage(err));
                else UI.status(statusEl, UI.errorMessage(err), "error");
            }).then(function () { btn.disabled = false; });
        });

        // ---------- تصویر پروفایل (کوچک‌سازی در مرورگر؛ اعتبارسنجی نهایی در سرور) ----------
        $("[data-avatar-input]").addEventListener("change", function (e) {
            var f = e.target.files[0]; e.target.value = "";
            if (!f) return;
            UI.fieldError(form, "avatar", "");
            if (["image/jpeg", "image/png", "image/webp"].indexOf(f.type) < 0) { UI.fieldError(form, "avatar", t("err.fileType")); return; }
            if (f.size > L.avatarMaxMB * 1048576) { UI.fieldError(form, "avatar", t("err.fileSize", { mb: L.avatarMaxMB })); return; }
            var img = new Image(), url = URL.createObjectURL(f);
            img.onload = function () {
                var c = document.createElement("canvas"), s = Math.min(img.width, img.height), size = 256;
                c.width = c.height = size;
                c.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
                URL.revokeObjectURL(url);
                api.profileUpdate({ avatar: c.toDataURL("image/jpeg", 0.85) }).then(function (u) { user = u; paintUser(); UI.toast(t("common.saved")); })
                    .catch(function (err) { UI.toast(UI.errorMessage(err), "error"); });
            };
            img.onerror = function () { UI.fieldError(form, "avatar", t("err.fileType")); };
            img.src = url;
        });
        $("[data-avatar-remove]").addEventListener("click", function () {
            api.profileUpdate({ avatar: "" }).then(function (u) { user = u; paintUser(); }).catch(function (err) { UI.toast(UI.errorMessage(err), "error"); });
        });

        // ---------- تغییر ایمیل / شماره با تأیید مالکیت ----------
        var vd = $("[data-verify-dialog]"), vb = $("[data-verify-body]");
        $$("[data-change]").forEach(function (btn) {
            btn.addEventListener("click", function () { openChange(btn.getAttribute("data-change")); });
        });
        function openChange(method) {
            vb.textContent = "";
            var label = t(method === "email" ? "set.newEmail" : "set.newPhone");
            var input = h("input", { class: "input", id: "chg-value", type: method === "email" ? "email" : "tel", dir: "ltr", autocomplete: "off", placeholder: method === "email" ? "name@example.com" : "+989123456789", maxlength: "120" });
            var err = h("p", { class: "field-error", role: "alert" });
            var send = h("button", { class: "btn btn-primary", type: "submit", text: t("set.sendCode") });
            var f1 = h("form", { class: "form", novalidate: "" }, [h("div", { class: "field" }, [h("label", { for: "chg-value", text: label }), input, err]), send]);
            vb.appendChild(f1);

            f1.addEventListener("submit", function (e) {
                e.preventDefault();
                var v = UI.normalizeDigits(input.value.trim()).replace(/[\s\-()]/g, "");
                err.textContent = "";
                if (method === "email" ? !UI.valid.email(v) : !/^\+\d{8,15}$/.test(v)) { err.textContent = t(method === "email" ? "err.email" : "err.phone"); return; }
                send.disabled = true;
                api.contactChangeRequest({ method: method, target: v }).then(function () { askCode(method, v); })
                    .catch(function (er) { err.textContent = UI.errorMessage(er); }).then(function () { send.disabled = false; });
            });
            vd.showModal();
            setTimeout(function () { input.focus(); }, 60);
        }
        function askCode(method, target) {
            vb.textContent = "";
            var code = h("input", { class: "input", type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: String(L.otpLength), dir: "ltr", "aria-label": t("auth.otpTitle"), id: "chg-code" });
            var err = h("p", { class: "field-error", role: "alert" });
            var ok = h("button", { class: "btn btn-primary", type: "submit", text: t("auth.otpVerify") });
            var f2 = h("form", { class: "form", novalidate: "" }, [
                h("p", { class: "muted small", text: t("auth.otpSub", { n: L.otpLength, target: target }) }),
                h("div", { class: "field" }, [h("label", { for: "chg-code", text: t("auth.otpTitle") }), code, err]), ok]);
            vb.appendChild(f2);
            code.focus();
            f2.addEventListener("submit", function (e) {
                e.preventDefault();
                var c = UI.normalizeDigits(code.value).replace(/\D/g, "");
                if (c.length !== L.otpLength) { err.textContent = t("auth.otpWrong"); return; }
                ok.disabled = true;
                api.contactChangeVerify({ method: method, target: target, code: c }).then(function (u) {
                    user = u; fill(); vd.close(); UI.toast(t("common.saved"));
                }).catch(function (er) { err.textContent = UI.errorMessage(er); }).then(function () { ok.disabled = false; });
            });
        }

        // ---------- خروج از همه دستگاه‌ها ----------
        $("[data-signout-all]").addEventListener("click", function () {
            api.signOutAll().then(function () { UI.hint.clear(); location.href = homeUrl(); })
                .catch(function (e) { UI.toast(UI.errorMessage(e), "error"); });
        });

        // ---------- حذف حساب ----------
        var dd = $("[data-delete-dialog]"), df = $("[data-delete-form]");
        $("[data-delete-open]").addEventListener("click", function () {
            $("[data-delete-text]").textContent = t("sec.deleteConfirm", { u: user.username });
            df.reset(); UI.clearErrors(df);
            dd.showModal();
        });
        df.addEventListener("submit", function (e) {
            e.preventDefault();
            UI.clearErrors(df);
            if (df.elements.confirm.value.trim() !== user.username) { UI.fieldError(df, "confirm", t("err.generic")); return; }
            api.deleteAccount({ confirm: user.username }).then(function () {
                UI.hint.clear(); dd.close(); UI.toast(t("sec.deleted"));
                setTimeout(function () { location.href = homeUrl(); }, 1200);
            }).catch(function (er) { UI.fieldError(df, "confirm", UI.errorMessage(er)); });
        });
    };

    boot();
});

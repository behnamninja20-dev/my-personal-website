/* =========================================================
   site.js | رفتار صفحات عمومی (صفحه اصلی، حریم خصوصی، قوانین)
   - فرم درخواست مشاوره
   - گروه‌های بازشونده فوتر در موبایل
   - دکمه بازگشت به بالا و سال جاری
   ========================================================= */
document.addEventListener("DOMContentLoaded", function () {
    "use strict";

    var UI = window.UI, t = window.t, api = window.AppAPI, cfg = window.SITE_CONFIG;

    // ---------- سال جاری ----------
    UI.$$("[data-year]").forEach(function (e) { e.textContent = new Date().getFullYear(); });

    // ---------- دکمه ورود/پنل ----------
    var sessionPromise = UI.bindAuthCta();

    // ---------- بازگشت به بالا ----------
    var top = UI.$("[data-to-top]");
    if (top) {
        top.addEventListener("click", function () {
            window.scrollTo({ top: 0, behavior: UI.reduceMotion ? "auto" : "smooth" });
        });
    }

    // ---------- فوتر: در دسکتاپ همه باز؛ در موبایل گروه‌های بازشونده ----------
    var cols = UI.$$(".footer-col");
    var mq = window.matchMedia("(max-width: 767px)");
    function syncFooter() {
        cols.forEach(function (d) { d.open = !mq.matches; });
    }
    cols.forEach(function (d) {
        var s = d.querySelector("summary");
        // در دسکتاپ عنوان ستون قابل بستن نیست
        s.addEventListener("click", function (e) { if (!mq.matches) e.preventDefault(); });
    });
    syncFooter();
    if (mq.addEventListener) mq.addEventListener("change", syncFooter); else mq.addListener(syncFooter);

    // ---------- فرم مشاوره ----------
    var form = UI.$("[data-consult-form]");
    if (!form) return;

    var success = UI.$("[data-consult-success]");
    var statusEl = UI.$("[data-form-status]", form);
    var submitBtn = UI.$('button[type="submit"]', form);
    var valueInput = form.elements.value;
    var valueLabel = UI.$("[data-value-label]", form);
    var note = UI.$("[data-consult-note] span");

    var attrs = {
        phone: { type: "tel", mode: "tel", ac: "tel", dir: "ltr" },
        email: { type: "email", mode: "email", ac: "email", dir: "ltr" },
        telegram: { type: "text", mode: "text", ac: "off", dir: "ltr" }
    };

    // با تغییر روش ارتباطی، برچسب و نوع فیلد عوض می‌شود
    function syncMethod() {
        var m = form.elements.method.value, a = attrs[m];
        valueLabel.textContent = valueInput.getAttribute("data-label-" + m);
        valueInput.type = a.type;
        valueInput.setAttribute("inputmode", a.mode);
        valueInput.setAttribute("autocomplete", a.ac);
        valueInput.setAttribute("dir", a.dir);
        UI.fieldError(form, "value", "");
    }
    UI.$$('input[name="method"]', form).forEach(function (r) { r.addEventListener("change", function () { syncMethod(); prefill(); }); });
    syncMethod();

    // اگر کاربر وارد حساب است، اطلاعات او خودکار پر می‌شود
    var user = null, prefilled = false;
    function prefill() {
        if (!user) return;
        var m = form.elements.method.value;
        if (!form.elements.name.value) form.elements.name.value = user.displayName || user.username || "";
        var v = m === "phone" ? user.phone : m === "email" ? user.email : "";
        if (v && !valueInput.value) valueInput.value = v;
        if (!prefilled && note) { note.textContent = t("consult.prefilled"); prefilled = true; }
    }
    sessionPromise.then(function (u) { user = u; prefill(); });

    // اعتبارسنجی؛ هر فیلد پیام خاص خودش را دارد
    function validate() {
        var d = {
            name: form.elements.name.value.trim(),
            method: form.elements.method.value,
            value: form.elements.value.value.trim(),
            subject: form.elements.subject.value,
            text: form.elements.text.value.trim(),
            time: form.elements.time.value
        };
        var ok = true;
        function bad(name, msg) { UI.fieldError(form, name, msg); ok = false; }
        UI.clearErrors(form);

        if (d.name.length < 2) bad("name", d.name ? t("err.minLen", { n: 2 }) : t("err.required"));
        if (!d.value) bad("value", t("err.required"));
        else if (d.method === "email" && !UI.valid.email(d.value)) bad("value", t("err.email"));
        else if (d.method === "telegram" && !UI.valid.telegram(d.value)) bad("value", t("err.telegram"));
        else if (d.method === "phone") {
            var digits = UI.normalizeDigits(d.value);
            if (!/^\+?[\d\s\-()]{7,20}$/.test(digits)) bad("value", t("err.phone"));
            else d.value = digits.replace(/[\s\-()]/g, "");
        }
        if (!d.subject) bad("subject", t("err.required"));
        if (d.text.length < 10) bad("text", d.text ? t("err.minLen", { n: 10 }) : t("err.required"));
        if (d.method === "telegram") d.value = d.value.replace(/^@/, "");
        return ok ? d : null;
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        var data = validate();
        if (!data) {
            var first = form.querySelector('[aria-invalid="true"]');
            if (first) first.focus();
            return;
        }
        UI.status(statusEl, "");
        submitBtn.disabled = true;
        submitBtn.textContent = submitBtn.getAttribute("data-busy-label");

        api.consultCreate(data).then(function () {
            form.hidden = true;
            success.hidden = false;
            success.querySelector("h3").setAttribute("tabindex", "-1");
            success.querySelector("h3").focus();
        }).catch(function (err) {
            UI.status(statusEl, UI.errorMessage(err), "error");
        }).then(function () {
            submitBtn.disabled = false;
            submitBtn.textContent = submitBtn.getAttribute("data-submit-label");
        });
    });

    UI.$("[data-consult-again]").addEventListener("click", function () {
        form.reset();
        syncMethod();
        prefill();
        success.hidden = true;
        form.hidden = false;
        form.elements.name.focus();
    });
});

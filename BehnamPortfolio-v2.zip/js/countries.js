/* =========================================================
   countries.js | فهرست کشورها برای شماره موبایل
   پرچم‌ها از flag-icons (نسخه ثابت) روی jsDelivr بارگذاری می‌شوند.
   اعتبارسنجی اینجا فقط برای راهنمایی کاربر است؛ اعتبارسنجی نهایی در سرور
   (مثلاً با libphonenumber) انجام می‌شود.
   ========================================================= */
(function () {
    "use strict";

    var FLAG_BASE = "https://cdn.jsdelivr.net/gh/lipis/flag-icons@7.2.3/flags/4x3/";

    // [iso, کد تلفن، نام فارسی، نام انگلیسی]
    var LIST = [
        ["ir", "98", "ایران", "Iran"], ["us", "1", "ایالات متحده", "United States"], ["gb", "44", "بریتانیا", "United Kingdom"],
        ["de", "49", "آلمان", "Germany"], ["tr", "90", "ترکیه", "Türkiye"], ["ae", "971", "امارات", "United Arab Emirates"],
        ["ca", "1", "کانادا", "Canada"], ["fr", "33", "فرانسه", "France"], ["nl", "31", "هلند", "Netherlands"],
        ["se", "46", "سوئد", "Sweden"], ["it", "39", "ایتالیا", "Italy"], ["es", "34", "اسپانیا", "Spain"],
        ["au", "61", "استرالیا", "Australia"], ["iq", "964", "عراق", "Iraq"], ["af", "93", "افغانستان", "Afghanistan"],
        ["am", "374", "ارمنستان", "Armenia"], ["az", "994", "جمهوری آذربایجان", "Azerbaijan"], ["ru", "7", "روسیه", "Russia"],
        ["in", "91", "هند", "India"], ["pk", "92", "پاکستان", "Pakistan"], ["qa", "974", "قطر", "Qatar"]
    ];

    window.COUNTRIES = LIST.map(function (c) {
        return { iso: c[0], dial: "+" + c[1], code: c[1], fa: c[2], en: c[3], flag: FLAG_BASE + c[0] + ".svg" };
    });

    // تبدیل ارقام فارسی/عربی به لاتین
    window.normalizeDigits = function (s) {
        return String(s || "").replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; })
            .replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; });
    };

    // خروجی: { ok, e164, national }
    window.parsePhone = function (country, raw) {
        var digits = window.normalizeDigits(raw).replace(/[\s\-().]/g, "");
        if (/[^\d+]/.test(digits)) return { ok: false };
        digits = digits.replace(/^\+/, "");
        if (digits.indexOf(country.code) === 0 && digits.length > country.code.length + 5) digits = digits.slice(country.code.length);
        digits = digits.replace(/^0+/, "");
        var ok = country.iso === "ir" ? /^9\d{9}$/.test(digits) : /^\d{6,14}$/.test(digits);
        return { ok: ok, national: digits, e164: "+" + country.code + digits };
    };
})();

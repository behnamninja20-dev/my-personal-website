/* =========================================================
   ui.js | ابزارهای مشترک رابط کاربری (همه صفحات)
   ========================================================= */
(function () {
    "use strict";

    var cfg = window.SITE_CONFIG;
    var t = window.t;
    var UI = {};

    UI.$ = function (s, root) { return (root || document).querySelector(s); };
    UI.$$ = function (s, root) { return Array.prototype.slice.call((root || document).querySelectorAll(s)); };

    UI.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // ---------- اعتبارسنجی ----------
    UI.isPlaceholder = function (v) { return !v || /^YOUR_/i.test(v); };

    UI.valid = {
        email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) && v.length <= 120; },
        telegram: function (v) { return /^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(String(v).replace(/^@/, "")); },
        username: function (v) {
            var l = cfg.limits;
            return v.length >= l.usernameMin && v.length <= l.usernameMax && /^[A-Za-z0-9._-]+$/.test(v) && !/^[._-]|[._-]$/.test(v);
        }
    };

    // تبدیل ارقام فارسی/عربی به لاتین
    UI.normalizeDigits = function (s) {
        return String(s || "").replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; })
            .replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; });
    };

    // ---------- خطای فیلد ----------
    UI.fieldError = function (form, name, msg) {
        var out = UI.$('[data-err="' + name + '"]', form);
        if (out) out.textContent = msg || "";
        var input = form.querySelector('[name="' + name + '"]');
        if (input && input.type !== "radio" && input.type !== "checkbox") {
            if (msg) input.setAttribute("aria-invalid", "true"); else input.removeAttribute("aria-invalid");
            if (out && out.id) input.setAttribute("aria-describedby", out.id);
        }
    };

    UI.clearErrors = function (form) {
        UI.$$("[data-err]", form).forEach(function (e) { e.textContent = ""; });
        UI.$$('[aria-invalid="true"]', form).forEach(function (e) { e.removeAttribute("aria-invalid"); });
    };

    UI.status = function (el, msg, kind) {
        if (!el) return;
        el.textContent = msg || "";
        el.classList.toggle("is-error", kind === "error");
        el.classList.toggle("is-ok", kind === "ok");
    };

    // تبدیل خطای API به پیام قابل‌فهم
    UI.errorMessage = function (e) {
        var map = {
            NOT_CONFIGURED: "err.notConfigured", NETWORK: "err.network", RATE_LIMITED: "err.rate",
            UNAUTHENTICATED: "err.unauth", INVALID_CODE: "auth.otpWrong", CODE_EXPIRED: "auth.otpExpired",
            TOO_MANY_ATTEMPTS: "auth.otpTooMany", ACCOUNT_NOT_FOUND: "err.accountNotFound", ACCOUNT_EXISTS: "err.accountExists",
            USERNAME_TAKEN: "err.usernameTaken", PROVIDER_DISABLED: "err.provider"
        };
        var code = e && e.code;
        if (code === "VALIDATION") return t("err.generic");
        if (code === "USERNAME_LOCKED") return t("set.usernameHint", { d: (e.extra && e.extra.days) || cfg.limits.usernameChangeDays });
        return t(map[code] || "err.generic", { provider: "" });
    };

    // ---------- Toast ----------
    UI.toast = function (msg, kind) {
        var region = UI.$("[data-toasts]");
        if (!region) {
            region = document.createElement("div");
            region.className = "toast-region";
            region.setAttribute("aria-live", "polite");
            region.setAttribute("data-toasts", "");
            document.body.appendChild(region);
        }
        var el = document.createElement("div");
        el.className = "toast" + (kind === "error" ? " is-error" : "");
        el.textContent = msg;
        region.appendChild(el);
        setTimeout(function () { el.remove(); }, 3600);
    };

    // ---------- ذخیره زبان و کنترل زبان ----------
    function initLangSwitch() {
        UI.$$("[data-lang-switch]").forEach(function (box) {
            var btn = UI.$(".lang-btn", box);
            function set(open) {
                box.classList.toggle("is-open", open);
                btn.setAttribute("aria-expanded", String(open));
            }
            btn.addEventListener("click", function (e) { e.stopPropagation(); set(!box.classList.contains("is-open")); });
            document.addEventListener("click", function (e) { if (!box.contains(e.target)) set(false); });
            document.addEventListener("keydown", function (e) {
                if (e.key === "Escape" && box.classList.contains("is-open")) { set(false); btn.focus(); }
            });
            UI.$$("[data-set-lang]", box).forEach(function (a) {
                a.addEventListener("click", function (e) {
                    var l = a.getAttribute("data-set-lang");
                    try { localStorage.setItem("lang", l); } catch (err) { }
                    if (a.classList.contains("is-current")) { e.preventDefault(); set(false); return; }
                    // اتصال ثابت: پارامتر و هش فعلی هم منتقل می‌شوند
                    e.preventDefault();
                    location.href = a.getAttribute("href") + location.search + location.hash;
                });
            });
        });
        // صفحه‌ای که با لینک مستقیم باز شده، زبان خودش را ذخیره می‌کند
        try { localStorage.setItem("lang", window.LANG); } catch (err) { }
    }

    // ---------- لینک‌های تماس (تلفن، تلگرام، ایمیل) ----------
    UI.bindContacts = function () {
        function setLink(kind, href, enabled) {
            UI.$$('[data-contact-link="' + kind + '"]').forEach(function (a) {
                var label = a.getAttribute("data-label"), off = a.getAttribute("data-label-off");
                if (enabled) {
                    a.setAttribute("href", href);
                    a.removeAttribute("aria-disabled");
                    a.removeAttribute("tabindex");
                    if (/^https?:/.test(href)) { a.setAttribute("target", "_blank"); a.setAttribute("rel", "noopener noreferrer"); }
                    if (label && a.classList.contains("btn")) a.textContent = label;
                } else {
                    a.removeAttribute("href");
                    a.setAttribute("aria-disabled", "true");
                    a.setAttribute("tabindex", "-1");
                    if (off && a.classList.contains("btn")) a.textContent = off;
                }
            });
        }
        function setValue(kind, v) { UI.$$('[data-contact-value="' + kind + '"]').forEach(function (e) { e.textContent = v; }); }

        setValue("phone", cfg.phone);
        setLink("phone", "tel:" + cfg.phone.replace(/[^\d+]/g, ""), true);

        setValue("telegram", cfg.telegram);
        var tgOk = !UI.isPlaceholder(cfg.telegram) && UI.valid.telegram(cfg.telegram);
        setLink("telegram", "https://t.me/" + String(cfg.telegram).replace(/^@/, ""), tgOk);

        setValue("email", cfg.email);
        var mailOk = !UI.isPlaceholder(cfg.email) && UI.valid.email(cfg.email);
        setLink("email", "mailto:" + cfg.email, mailOk);

        // شبکه‌های اجتماعی (فقط لینک‌های واقعی https)
        var list = UI.$("[data-social-list]");
        if (list && cfg.socials && cfg.socials.length) {
            list.textContent = "";
            cfg.socials.forEach(function (s) {
                if (!/^https:\/\//.test(s.url)) return;
                var a = document.createElement("a");
                a.href = s.url; a.textContent = s.name; a.target = "_blank"; a.rel = "noopener noreferrer";
                list.appendChild(a);
            });
        }
    };

    // ---------- دکمه ورود/پنل در هدر ----------
    // فقط وقتی قبلاً وارد شده باشد از سرور می‌پرسیم (درخواست بی‌دلیل نمی‌فرستیم)
    UI.hint = {
        get: function () { try { return localStorage.getItem("bh_session_hint") === "1"; } catch (e) { return false; } },
        set: function () { try { localStorage.setItem("bh_session_hint", "1"); } catch (e) { } },
        clear: function () { try { localStorage.removeItem("bh_session_hint"); } catch (e) { } }
    };

    UI.bindAuthCta = function () {
        var cta = UI.$("[data-auth-cta]");
        if (!cta || !UI.hint.get()) return Promise.resolve(null);
        return window.AppAPI.session().then(function (u) {
            if (u) {
                cta.textContent = cta.getAttribute("data-label-user");
                cta.setAttribute("href", cta.getAttribute("data-href-user"));
            } else { UI.hint.clear(); }
            return u;
        }).catch(function () { return null; });
    };

    // آدرس بازگشت امن: فقط همین سایت
    UI.safeNext = function (raw) {
        if (!raw) return "";
        try {
            var u = new URL(raw, location.href);
            return u.origin === location.origin ? u.pathname + u.search + u.hash : "";
        } catch (e) { return ""; }
    };

    document.addEventListener("DOMContentLoaded", function () {
        initLangSwitch();
        UI.bindContacts();
    });

    window.UI = UI;
})();
